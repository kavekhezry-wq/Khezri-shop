import { MapPin, Menu, Search, ShoppingBasket, X } from 'lucide-react';
import { toPersianDigits } from '../utils/storeHelpers';
import { PWAInstallButton } from './PWAInstallButton';

export type ActivePage = 'storefront' | 'admin';

interface HeaderProps {
  activePage: ActivePage;
  onNavigate: (page: ActivePage) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  isSideDrawerOpen: boolean;
  onToggleSideDrawer: () => void;
  activeLocationLabel?: string;
  cartCount?: number;
}

export function Header({
  activePage,
  onNavigate,
  searchQuery,
  onSearchChange,
  isSideDrawerOpen,
  onToggleSideDrawer,
  activeLocationLabel,
  cartCount = 0,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-sm border-b border-sky-100">
      <div className="max-w-[1600px] mx-auto px-3 sm:px-6 h-14 flex items-center justify-between gap-2 sm:gap-4">
        {/* Zone 1 (Right in RTL): App Logo with 'خضری' below it + Collapsible Side Drawer Toggle */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          <button
            type="button"
            onClick={() => onNavigate('storefront')}
            title="صفحه اصلی خضری"
            className="flex flex-col items-center justify-center shrink-0 cursor-pointer group select-none"
          >
            <div className="w-8 h-8 rounded-xl bg-red-600 group-hover:bg-red-700 text-white flex items-center justify-center shadow-xs transition-colors">
              <ShoppingBasket className="w-4 h-4" />
            </div>
            <span className="text-[10px] font-black text-slate-800 group-hover:text-red-600 mt-0.5 leading-none transition-colors">
              خضری
            </span>
          </button>

          <button
            type="button"
            onClick={onToggleSideDrawer}
            aria-expanded={isSideDrawerOpen}
            aria-label={isSideDrawerOpen ? 'بستن منوی کاربری و مکان' : 'باز کردن منوی کاربری و مکان'}
            className={`inline-flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs sm:text-sm font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              isSideDrawerOpen
                ? 'bg-sky-600 text-white border-sky-600'
                : 'bg-sky-50 hover:bg-sky-100 text-sky-900 border-sky-200'
            }`}
          >
            {isSideDrawerOpen ? (
              <X className="w-4 h-4 shrink-0" />
            ) : (
              <Menu className="w-4 h-4 shrink-0" />
            )}
            <span>منو و مکان</span>
            {cartCount > 0 && (
              <span className="px-1.5 py-0.5 rounded-md bg-red-600 text-white font-mono-num text-[11px] font-bold">
                {toPersianDigits(cartCount)}
              </span>
            )}
            {activeLocationLabel && (
              <span
                className={`hidden sm:inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md text-[10px] font-semibold ${
                  isSideDrawerOpen
                    ? 'bg-sky-700 text-sky-50'
                    : 'bg-white text-sky-700 border border-sky-200'
                }`}
              >
                <MapPin className="w-3 h-3 text-red-600 shrink-0" />
                <span className="max-w-[70px] truncate">{activeLocationLabel}</span>
              </span>
            )}
          </button>
        </div>

        {/* Zone 2 (Middle): Quick Search Bar */}
        <div className="flex-1 max-w-md min-w-[90px]">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-sky-600 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                onSearchChange(e.target.value);
                if (activePage !== 'storefront') {
                  onNavigate('storefront');
                }
              }}
              placeholder="جستجوی سریع در ۱۰ ستون..."
              aria-label="جستجوی سریع محصولات"
              className="w-full pr-8 pl-7 py-1.5 text-xs bg-sky-50/70 border border-sky-200 rounded-lg text-slate-900 placeholder:text-slate-400 focus:outline-none focus:bg-white focus:border-sky-500 transition-colors"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-red-600 cursor-pointer"
                aria-label="پاک کردن جستجو"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Zone 3 (Left in RTL): Navigation & PWA Install */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <nav className="hidden md:flex items-center gap-4 text-xs sm:text-sm font-medium text-slate-600">
            <button
              type="button"
              onClick={() => onNavigate('storefront')}
              className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activePage === 'storefront'
                  ? 'border-red-600 text-slate-900 font-semibold'
                  : 'border-transparent hover:text-sky-700 hover:border-sky-300'
              }`}
            >
              صفحه اصلی
            </button>
            <button
              type="button"
              onClick={() => onNavigate('admin')}
              className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activePage === 'admin'
                  ? 'border-sky-600 text-sky-700 font-semibold'
                  : 'border-transparent hover:text-sky-700 hover:border-sky-300'
              }`}
            >
              پنل مدیریت
            </button>
          </nav>

          <button
            type="button"
            onClick={() => onNavigate(activePage === 'admin' ? 'storefront' : 'admin')}
            className="md:hidden px-2.5 py-1.5 text-xs font-semibold text-sky-700 bg-sky-50 rounded-lg hover:bg-sky-100 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            {activePage === 'admin' ? 'صفحه اصلی' : 'مدیریت'}
          </button>

          <PWAInstallButton />
        </div>
      </div>
    </header>
  );
}

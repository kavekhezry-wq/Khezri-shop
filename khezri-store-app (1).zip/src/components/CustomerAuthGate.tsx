import {
  ArrowRight,
  KeyRound,
  MessageSquare,
  Phone,
  ShieldCheck,
  ShoppingBasket,
  User,
} from 'lucide-react';
import { useState } from 'react';
import type { CustomerUser } from '../types/store';
import { toPersianDigits } from '../utils/storeHelpers';

interface CustomerAuthGateProps {
  onAuthenticated: (token: string, customer: CustomerUser) => void;
  onSwitchToAdmin: () => void;
}

export function CustomerAuthGate({
  onAuthenticated,
  onSwitchToAdmin,
}: CustomerAuthGateProps) {
  const [step, setStep] = useState<'request' | 'verify'>('request');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [normalizedPhone, setNormalizedPhone] = useState('');
  const [adminPhone, setAdminPhone] = useState('09146265841');
  const [smsChannel, setSmsChannel] = useState<'webhook' | 'kavenegar' | 'admin_panel'>('admin_panel');
  const [code, setCode] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [infoMsg, setInfoMsg] = useState<string | null>(null);

  const requestOtp = async () => {
    setErrorMsg(null);
    setInfoMsg(null);

    if (name.trim().length < 2) {
      setErrorMsg('لطفاً نام و نام خانوادگی خود را وارد کنید.');
      return;
    }
    if (!phone.trim()) {
      setErrorMsg('لطفاً شماره موبایل خود را وارد کنید.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/request-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: name.trim(), phone: phone.trim() }),
      });

      const data = (await res.json().catch(() => ({}))) as {
        ok?: boolean;
        phone?: string;
        adminPhone?: string;
        smsDispatchedVia?: 'webhook' | 'kavenegar' | 'admin_panel';
        error?: string;
      };

      if (!res.ok || !data.ok) {
        setErrorMsg(data.error || 'خطا در ارسال درخواست کد ورود.');
        return;
      }

      setNormalizedPhone(data.phone || phone.trim());
      setAdminPhone(data.adminPhone || '09146265841');
      setSmsChannel(data.smsDispatchedVia || 'admin_panel');
      setStep('verify');
      setCode('');
      setInfoMsg(
        `درخواست کد ورود برای ${name.trim()} به شماره مدیر (${data.adminPhone || '09146265841'}) ارسال شد.`,
      );
    } catch {
      setErrorMsg('خطا در برقراری ارتباط با سرور. لطفاً دوباره تلاش کنید.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await requestOtp();
  };

  const handleVerifySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (code.trim().length < 6) {
      setErrorMsg('لطفاً کد ۶ رقمی یکبار مصرف را کامل وارد کنید.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: normalizedPhone || phone.trim(),
          code: code.trim(),
        }),
      });

      const data = (await res.json().catch(() => ({}))) as {
        token?: string;
        customer?: CustomerUser;
        error?: string;
      };

      if (!res.ok || !data.token || !data.customer) {
        setErrorMsg(data.error || 'کد واردشده تایید نشد.');
        return;
      }

      onAuthenticated(data.token, data.customer);
    } catch {
      setErrorMsg('خطا در برقراری ارتباط با سرور. لطفاً دوباره تلاش کنید.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-10 bg-slate-50">
      <div className="w-full max-w-md space-y-4">
        <div className="bg-white border border-sky-100 rounded-2xl shadow-sm overflow-hidden">
          <div className="bg-sky-600 text-white px-6 py-5 flex items-center gap-3.5">
            <div className="flex flex-col items-center justify-center shrink-0">
              <div className="w-11 h-11 rounded-xl bg-red-600 flex items-center justify-center shadow-xs">
                <ShoppingBasket className="w-5 h-5" />
              </div>
              <span className="text-[10px] font-black text-white mt-1 leading-none tracking-tight">
                خضری
              </span>
            </div>
            <div>
              <h1 className="text-base font-extrabold">ورود به فروشگاه خضری</h1>
              <p className="text-xs text-sky-100 mt-0.5">
                {step === 'request'
                  ? 'برای مشاهده محصولات، با نام و شماره موبایل خود وارد شوید'
                  : 'کد یکبار مصرف ۶ رقمی دریافت‌شده را وارد نمایید'}
              </p>
            </div>
          </div>

          {step === 'request' ? (
            <form onSubmit={handleRequestSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  نام و نام خانوادگی *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="text"
                    required
                    autoFocus
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثلاً: علی رضایی"
                    className="w-full pr-9 pl-3.5 py-2.5 text-sm bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  شماره تلفن همراه *
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                  <input
                    type="tel"
                    dir="ltr"
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="09123456789"
                    className="w-full pr-9 pl-3.5 py-2.5 text-sm font-mono-num text-left bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-sky-500"
                  />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-sky-50 border border-sky-100 text-[11px] text-sky-900 leading-relaxed flex items-start gap-2">
                <MessageSquare className="w-4 h-4 text-sky-600 shrink-0 mt-0.5" />
                <span>
                  پس از ثبت درخواست، کد یکبار مصرف ورود به شماره مدیریت فروشگاه (
                  <span dir="ltr" className="font-mono-num font-bold">
                    {adminPhone}
                  </span>
                  ) ارسال شده و پس از تایید، برای شما فرستاده می‌شود.
                </span>
              </div>

              {errorMsg && (
                <div className="px-3.5 py-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold">
                  {errorMsg}
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-bold transition-colors cursor-pointer disabled:opacity-60"
              >
                <KeyRound className="w-4 h-4" />
                <span>{submitting ? 'در حال ثبت درخواست...' : 'درخواست کد ورود یکبار مصرف'}</span>
              </button>
            </form>
          ) : (
            <form onSubmit={handleVerifySubmit} className="p-6 space-y-4">
              <div className="p-3.5 rounded-xl bg-sky-50 border border-sky-100 space-y-1 text-xs">
                <div className="flex items-center justify-between text-slate-700">
                  <span>نام:</span>
                  <span className="font-bold text-slate-900">{name.trim()}</span>
                </div>
                <div className="flex items-center justify-between text-slate-700">
                  <span>شماره موبایل:</span>
                  <span dir="ltr" className="font-mono-num font-bold text-slate-900">
                    {normalizedPhone}
                  </span>
                </div>
                <div className="pt-1.5 mt-1.5 border-t border-sky-200/70 text-[11px] text-sky-900 leading-relaxed">
                  {smsChannel === 'admin_panel'
                    ? `کد یکبار مصرف در پنل مدیریت برای شماره ${adminPhone} ثبت شد. کد ۶ رقمی ارسال‌شده از طرف مدیر فروشگاه را وارد کنید:`
                    : `پیامک کد یکبار مصرف به شماره ${adminPhone} ارسال شد. پس از دریافت از مدیر فروشگاه، کد ۶ رقمی را وارد کنید:`}
                </div>
              </div>

              {infoMsg && (
                <div className="px-3.5 py-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-semibold">
                  {infoMsg}
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  کد یکبار مصرف ۶ رقمی *
                </label>
                <input
                  type="text"
                  inputMode="numeric"
                  dir="ltr"
                  maxLength={6}
                  required
                  autoFocus
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="------"
                  className="w-full px-4 py-3 text-lg font-mono-num font-bold text-center tracking-[0.4em] bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-sky-500"
                />
                <p className="text-[11px] text-slate-400 mt-1">
                  اعتبار کد: {toPersianDigits(10)} دقیقه
                </p>
              </div>

              {errorMsg && (
                <div className="px-3.5 py-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold">
                  {errorMsg}
                </div>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-bold transition-colors cursor-pointer disabled:opacity-60"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>{submitting ? 'در حال بررسی کد...' : 'تایید و ورود به فروشگاه'}</span>
              </button>

              <div className="flex items-center justify-between pt-1 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    setStep('request');
                    setErrorMsg(null);
                    setInfoMsg(null);
                  }}
                  className="inline-flex items-center gap-1 text-slate-600 hover:text-slate-900 font-semibold cursor-pointer"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                  <span>ویرایش نام یا شماره</span>
                </button>
                <button
                  type="button"
                  disabled={submitting}
                  onClick={requestOtp}
                  className="text-sky-700 hover:text-sky-900 font-bold cursor-pointer disabled:opacity-50"
                >
                  درخواست مجدد کد
                </button>
              </div>
            </form>
          )}
        </div>

        <div className="text-center">
          <button
            type="button"
            onClick={onSwitchToAdmin}
            className="text-xs font-semibold text-slate-500 hover:text-sky-700 underline underline-offset-4 transition-colors cursor-pointer"
          >
            ورود مدیر فروشگاه (مشاهده کدهای ورود و مدیریت کالا)
          </button>
        </div>
      </div>
    </div>
  );
}

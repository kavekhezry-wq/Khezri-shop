import {
  Candy,
  Coffee,
  Cookie,
  Croissant,
  Droplets,
  Fish,
  Milk,
  Nut,
  ShoppingBasket,
  Sparkles,
  Wheat,
} from 'lucide-react';

interface CategorySymbolProps {
  iconKey?: string;
  className?: string;
}

export function CategorySymbol({ iconKey, className = 'w-4 h-4' }: CategorySymbolProps) {
  switch (iconKey) {
    case 'wheat':
      return <Wheat className={className} />;
    case 'droplets':
      return <Droplets className={className} />;
    case 'milk':
      return <Milk className={className} />;
    case 'croissant':
      return <Croissant className={className} />;
    case 'coffee':
      return <Coffee className={className} />;
    case 'fish':
      return <Fish className={className} />;
    case 'candy':
      return <Candy className={className} />;
    case 'nut':
      return <Nut className={className} />;
    case 'cookie':
      return <Cookie className={className} />;
    case 'sparkles':
      return <Sparkles className={className} />;
    default:
      return <ShoppingBasket className={className} />;
  }
}

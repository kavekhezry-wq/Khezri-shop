import { CreditCard, Minus, Plus, ShoppingBag, Trash2, X } from 'lucide-react';
import type { CartItem, Category, Product } from '../types/store';
import { formatToman, toPersianDigits } from '../utils/storeHelpers';
import { CategorySymbol } from './CategorySymbol';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  categories: Category[];
  products: Product[];
  onUpdateQty: (productId: string, qty: number) => void;
  onRemoveItem: (productId: string) => void;
  onClearCart: () => void;
  onProceedToCheckout: () => void;
}

export function CartDrawer({
  isOpen,
  onClose,
  cart,
  categories,
  products,
  onUpdateQty,
  onRemoveItem,
  onClearCart,
  onProceedToCheckout,
}: CartDrawerProps) {
  if (!isOpen) return null;

  const productMap = new Map(products.map((p) => [p.id, p]));
  const categoryMap = new Map(categories.map((c) => [c.id, c]));

  const detailedItems = cart
    .map((item) => {
      const product = productMap.get(item.productId);
      if (!product) return null;
      const category = categoryMap.get(product.categoryId);
      return {
        ...item,
        product,
        category,
        lineTotal: product.price * item.quantity,
      };
    })
    .filter((x): x is NonNullable<typeof x> => x !== null);

  const subtotal = detailedItems.reduce((acc, i) => acc + i.lineTotal, 0);
  const shippingCost = subtotal === 0 || subtotal >= 1500000 ? 0 : 65000;
  const grandTotal = subtotal + shippingCost;

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/45 backdrop-blur-xs flex justify-end"
      onClick={onClose}
    >
      <aside
        className="w-full max-w-md bg-white h-full flex flex-col border-r border-sky-100 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
        aria-label="سبد خرید"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-sky-100 bg-sky-50/60">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-red-600" />
            <h2 className="text-base font-extrabold text-slate-900">
              سبد خرید خضری ({toPersianDigits(detailedItems.reduce((a, b) => a + b.quantity, 0))} کالا)
            </h2>
          </div>
          <div className="flex items-center gap-2">
            {detailedItems.length > 0 && (
              <button
                type="button"
                onClick={onClearCart}
                className="text-xs font-medium text-slate-500 hover:text-red-600 transition-colors cursor-pointer"
              >
                حذف همه
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-white cursor-pointer"
              aria-label="بستن سبد خرید"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Cart Items */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {detailedItems.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-12 px-4">
              <div className="w-14 h-14 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center mb-3">
                <ShoppingBag className="w-7 h-7" />
              </div>
              <p className="text-sm font-bold text-slate-900 mb-1">سبد خرید شما خالی است</p>
              <p className="text-xs text-slate-500 max-w-xs">
                از میان ۱۰ ستون خواروبار و مواد غذایی در صفحه اصلی اقلام مورد نیاز خود را اضافه کنید.
              </p>
            </div>
          ) : (
            detailedItems.map(({ product, category, quantity, lineTotal }) => (
              <div
                key={product.id}
                className="flex gap-3 p-3 rounded-xl border border-slate-200 bg-white"
              >
                <div className="w-11 h-11 rounded-lg bg-sky-50 border border-sky-100 text-sky-700 flex items-center justify-center shrink-0">
                  <CategorySymbol iconKey={category?.iconKey} className="w-5 h-5" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-xs font-bold text-slate-900 line-clamp-2 leading-snug">
                      {product.name}
                    </h3>
                    <button
                      type="button"
                      onClick={() => onRemoveItem(product.id)}
                      className="text-slate-400 hover:text-red-600 p-0.5 shrink-0 cursor-pointer"
                      aria-label={`حذف ${product.name}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-500 mt-0.5 tabular-nums">
                    موجودی: {toPersianDigits(product.stock)} عدد
                  </p>

                  <div className="flex items-center justify-between gap-2 mt-2.5">
                    <div className="inline-flex items-center border border-slate-200 rounded-lg bg-slate-50">
                      <button
                        type="button"
                        onClick={() => onUpdateQty(product.id, quantity - 1)}
                        className="p-1.5 text-slate-600 hover:text-slate-900 cursor-pointer"
                        aria-label="کاهش"
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-2.5 text-xs font-bold tabular-nums">
                        {toPersianDigits(quantity)}
                      </span>
                      <button
                        type="button"
                        disabled={quantity >= product.stock}
                        onClick={() => onUpdateQty(product.id, quantity + 1)}
                        className="p-1.5 text-slate-600 hover:text-slate-900 disabled:opacity-40 cursor-pointer disabled:cursor-not-allowed"
                        aria-label="افزایش"
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <span className="text-xs font-extrabold text-slate-900 tabular-nums">
                      {formatToman(lineTotal)}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Summary & Online Checkout CTA */}
        {detailedItems.length > 0 && (
          <div className="border-t border-sky-100 bg-sky-50/40 p-5 space-y-3">
            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>جمع کل کالاها</span>
                <span className="tabular-nums font-medium">{formatToman(subtotal)}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>هزینه ارسال (رایگان بالای ۱.۵ میلیون)</span>
                <span className="tabular-nums font-medium">
                  {shippingCost === 0 ? 'رایگان' : formatToman(shippingCost)}
                </span>
              </div>
              <div className="pt-2 border-t border-sky-200/70 flex justify-between text-sm font-extrabold text-slate-900">
                <span>مبلغ قابل پرداخت</span>
                <span className="tabular-nums text-red-600">{formatToman(grandTotal)}</span>
              </div>
            </div>

            <button
              type="button"
              onClick={onProceedToCheckout}
              className="w-full py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-bold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <CreditCard className="w-4 h-4" />
              <span>ادامه و پرداخت آنلاین</span>
            </button>
          </div>
        )}
      </aside>
    </div>
  );
}

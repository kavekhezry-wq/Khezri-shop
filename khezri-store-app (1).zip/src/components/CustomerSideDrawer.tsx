import {
  CheckCircle2,
  Compass,
  Download,
  LogOut,
  MapPin,
  Phone,
  Plus,
  ShoppingBag,
  Trash2,
  User,
  X,
} from 'lucide-react';
import { useEffect, useState } from 'react';
import type { CustomerLocation, CustomerUser } from '../types/store';
import { toPersianDigits } from '../utils/storeHelpers';

interface CustomerSideDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  customerUser: CustomerUser | null;
  isAdmin: boolean;
  cartCount: number;
  onOpenCart: () => void;
  locations: CustomerLocation[];
  selectedLocationId: string | null;
  onSelectLocation: (id: string) => void;
  onAddLocation: (location: Omit<CustomerLocation, 'id' | 'updatedAt'>) => void;
  onDeleteLocation: (id: string) => void;
  onLogout: () => void;
  onNotify: (msg: string) => void;
}

export function CustomerSideDrawer({
  isOpen,
  onClose,
  customerUser,
  isAdmin,
  cartCount,
  onOpenCart,
  locations,
  selectedLocationId,
  onSelectLocation,
  onAddLocation,
  onDeleteLocation,
  onLogout,
  onNotify,
}: CustomerSideDrawerProps) {
  const [isAddingForm, setIsAddingForm] = useState(false);
  const [label, setLabel] = useState('منزل');
  const [address, setAddress] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locatingGps, setLocatingGps] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setIsAddingForm(false);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleDetectGps = () => {
    if (!navigator.geolocation) {
      onNotify('مرورگر شما از ثبت موقعیت GPS پشتیبانی نمی‌کند.');
      return;
    }
    setLocatingGps(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setCoords({
          lat: Number(pos.coords.latitude.toFixed(6)),
          lng: Number(pos.coords.longitude.toFixed(6)),
        });
        setLocatingGps(false);
        onNotify('مختصات موقعیت مکانی شما ثبت شد.');
      },
      () => {
        setLocatingGps(false);
        onNotify('دسترسی به موقعیت مکانی داده نشد؛ می‌توانید آدرس را دستی بنویسید.');
      },
      { enableHighAccuracy: true, timeout: 8000 },
    );
  };

  const handleSubmitLocation = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanAddress = address.trim();
    if (cleanAddress.length < 5) {
      onNotify('لطفاً آدرس دقیق مکان را وارد کنید.');
      return;
    }
    onAddLocation({
      label: label.trim() || 'مکان من',
      address: cleanAddress,
      postalCode: postalCode.trim() || undefined,
      lat: coords?.lat,
      lng: coords?.lng,
    });
    setAddress('');
    setPostalCode('');
    setCoords(null);
    setIsAddingForm(false);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/45 backdrop-blur-xs flex justify-start"
      onClick={onClose}
    >
      <aside
        className="w-[85vw] sm:w-[320px] md:w-1/3 md:max-w-[360px] bg-white h-full flex flex-col border-l border-sky-100 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
        aria-label="منوی مشتری و مدیریت مکان"
      >
        {/* Top Drawer Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-sky-600 text-white">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="w-9 h-9 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
              <User className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <p className="text-sm font-extrabold truncate">
                {customerUser?.name || (isAdmin ? 'مدیر فروشگاه' : 'کاربر مهمان')}
              </p>
              <p dir="ltr" className="text-[11px] text-sky-100 font-mono-num text-right truncate">
                {customerUser?.phone || (isAdmin ? 'دسترسی مدیریت' : '')}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-sky-100 hover:text-white hover:bg-sky-700 cursor-pointer"
            aria-label="بستن منو"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content: Cart + Customer Locations */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Shopping Cart Button inside Menu */}
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenCart();
            }}
            className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 transition-colors cursor-pointer"
          >
            <span className="inline-flex items-center gap-2 text-xs font-extrabold text-slate-900">
              <span className="w-7 h-7 rounded-lg bg-red-600 text-white flex items-center justify-center shrink-0">
                <ShoppingBag className="w-3.5 h-3.5" />
              </span>
              <span>سبد خرید</span>
            </span>
            <span className="inline-flex items-center gap-1.5 text-[11px] font-bold text-red-700 bg-white px-2.5 py-1 rounded-lg border border-red-200 font-mono-num">
              <span>{toPersianDigits(cartCount)} کالا</span>
            </span>
          </button>

          <div className="flex items-center justify-between gap-2 pt-1">
            <div className="flex items-center gap-1.5 text-slate-900">
              <MapPin className="w-4 h-4 text-red-600 shrink-0" />
              <h2 className="text-sm font-extrabold">مکان‌های تحویل من</h2>
            </div>

            <button
              type="button"
              onClick={() => setIsAddingForm((prev) => !prev)}
              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 text-xs font-bold transition-colors cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isAddingForm ? 'بستن فرم' : 'افزودن مکان'}</span>
            </button>
          </div>

          {/* Add Location Form */}
          {isAddingForm && (
            <form
              onSubmit={handleSubmitLocation}
              className="p-3.5 rounded-2xl bg-sky-50/70 border border-sky-200 space-y-3"
            >
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  عنوان مکان (مثلاً خانه، محل کار)
                </label>
                <div className="flex gap-1.5 mb-1.5">
                  {['منزل', 'محل کار', 'مغازه'].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setLabel(preset)}
                      className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border cursor-pointer transition-colors ${
                        label === preset
                          ? 'bg-sky-600 text-white border-sky-600'
                          : 'bg-white text-slate-700 border-slate-200 hover:bg-sky-50'
                      }`}
                    >
                      {preset}
                    </button>
                  ))}
                </div>
                <input
                  type="text"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                  placeholder="عنوان دلخواه..."
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  آدرس کامل مکان *
                </label>
                <textarea
                  rows={2}
                  required
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="شهر، خیابان، کوچه، پلاک، واحد..."
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  کد پستی (اختیاری)
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  placeholder="1415512345"
                  className="w-full px-3 py-2 text-xs font-mono-num text-left bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="flex items-center justify-between gap-2">
                <button
                  type="button"
                  disabled={locatingGps}
                  onClick={handleDetectGps}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white hover:bg-sky-100 border border-sky-200 text-sky-800 text-[11px] font-bold cursor-pointer disabled:opacity-60"
                >
                  <Compass className={`w-3.5 h-3.5 ${locatingGps ? 'animate-spin' : ''}`} />
                  <span>{locatingGps ? 'در حال دریافت...' : 'ثبت موقعیت GPS فعلی'}</span>
                </button>

                {coords && (
                  <span dir="ltr" className="text-[10px] font-mono-num text-emerald-700 font-bold">
                    {coords.lat}, {coords.lng}
                  </span>
                )}
              </div>

              <button
                type="submit"
                className="w-full py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-colors cursor-pointer"
              >
                ذخیره مکان
              </button>
            </form>
          )}

          {/* Saved Locations List */}
          {locations.length === 0 ? (
            <div className="p-4 rounded-2xl border border-dashed border-slate-200 text-center text-xs text-slate-500">
              هنوز مکانی ثبت نکرده‌اید. مکان خود را اضافه کنید تا هنگام ثبت سفارش به‌صورت خودکار درج شود.
            </div>
          ) : (
            <div className="space-y-2.5">
              {locations.map((loc) => {
                const isSelected = loc.id === selectedLocationId;
                return (
                  <div
                    key={loc.id}
                    className={`p-3 rounded-xl border transition-colors ${
                      isSelected
                        ? 'bg-sky-50/70 border-sky-400'
                        : 'bg-white border-slate-200 hover:border-sky-200'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2">
                      <button
                        type="button"
                        onClick={() => onSelectLocation(loc.id)}
                        className="flex-1 text-right space-y-1 cursor-pointer"
                      >
                        <div className="flex items-center gap-1.5">
                          {isSelected ? (
                            <CheckCircle2 className="w-4 h-4 text-sky-600 shrink-0" />
                          ) : (
                            <MapPin className="w-4 h-4 text-slate-400 shrink-0" />
                          )}
                          <span className="text-xs font-extrabold text-slate-900">
                            {loc.label}
                          </span>
                          {isSelected && (
                            <span className="text-[10px] font-bold text-sky-700 bg-white px-1.5 py-0.5 rounded border border-sky-200">
                              مکان فعال
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-600 leading-relaxed">{loc.address}</p>
                        {(loc.postalCode || (loc.lat !== undefined && loc.lng !== undefined)) && (
                          <div className="flex flex-wrap items-center gap-2 text-[10px] text-slate-400 font-mono-num">
                            {loc.postalCode && <span>کد پستی: {loc.postalCode}</span>}
                            {loc.lat !== undefined && loc.lng !== undefined && (
                              <span dir="ltr">
                                GPS: {loc.lat}, {loc.lng}
                              </span>
                            )}
                          </div>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => onDeleteLocation(loc.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 shrink-0 cursor-pointer"
                        aria-label={`حذف ${loc.label}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer: Download app zip + Support + Logout */}
        <div className="border-t border-sky-100 bg-slate-50 p-4 space-y-2">
          <a
            href="/api/download-app"
            download="khezri-store-app.zip"
            className="flex items-center justify-between px-3 py-2 rounded-xl bg-sky-50 border border-sky-200 hover:bg-sky-100 transition-colors text-xs font-bold text-sky-900"
          >
            <span className="inline-flex items-center gap-1.5">
              <Download className="w-3.5 h-3.5 text-sky-600 shrink-0" />
              <span>دانلود فایل کامل برنامه (ZIP)</span>
            </span>
            <span className="text-[10px] text-sky-600 font-mono-num font-bold bg-white px-1.5 py-0.5 rounded border border-sky-200">
              دانلود
            </span>
          </a>

          <a
            href="tel:09146265841"
            className="flex items-center justify-between px-3 py-2 rounded-xl bg-white border border-sky-200 hover:border-sky-400 transition-colors text-xs"
          >
            <span className="inline-flex items-center gap-1.5 font-bold text-slate-700">
              <Phone className="w-3.5 h-3.5 text-sky-600 shrink-0" />
              <span>پشتیبانی</span>
            </span>
            <span dir="ltr" className="font-mono-num font-extrabold text-sky-800">
              09146265841
            </span>
          </a>

          <button
            type="button"
            onClick={() => {
              onClose();
              onLogout();
            }}
            className="w-full py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs sm:text-sm font-bold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-xs"
          >
            <LogOut className="w-4 h-4" />
            <span>خروج کاربر از اپلیکیشن</span>
          </button>
        </div>
      </aside>
    </div>
  );
}

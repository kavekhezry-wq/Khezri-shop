import { CheckCircle2, CreditCard, Lock, Printer, ShieldCheck, Truck, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { CartItem, Order, Product } from '../types/store';
import { formatDateTimeFa, formatToman, toPersianDigits } from '../utils/storeHelpers';

interface OnlineCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  products: Product[];
  authToken: string | null;
  initialCustomerName?: string;
  initialCustomerPhone?: string;
  initialCustomerAddress?: string;
  initialPostalCode?: string;
  onOrderCompleted: (order: Order) => void;
}

export function OnlineCheckoutModal({
  isOpen,
  onClose,
  cart,
  products,
  authToken,
  initialCustomerName = '',
  initialCustomerPhone = '',
  initialCustomerAddress = '',
  initialPostalCode = '',
  onOrderCompleted,
}: OnlineCheckoutModalProps) {
  const [step, setStep] = useState<'shipping' | 'gateway' | 'receipt'>('shipping');
  const [customerName, setCustomerName] = useState(initialCustomerName);
  const [customerPhone, setCustomerPhone] = useState(initialCustomerPhone);
  const [customerAddress, setCustomerAddress] = useState(initialCustomerAddress);
  const [postalCode, setPostalCode] = useState(initialPostalCode);

  // Gateway fields
  const [cardNumber, setCardNumber] = useState('6037997512345678');
  const [cvv2, setCvv2] = useState('418');
  const [expMonth, setExpMonth] = useState('09');
  const [expYear, setExpYear] = useState('07');
  const [otp, setOtp] = useState('');
  const [generatedOtp, setGeneratedOtp] = useState<string | null>(null);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);

  useEffect(() => {
    if (!isOpen) return;
    setCustomerName((prev) => prev || initialCustomerName);
    setCustomerPhone((prev) => prev || initialCustomerPhone);
    setCustomerAddress((prev) => prev || initialCustomerAddress);
    setPostalCode((prev) => prev || initialPostalCode);
  }, [
    isOpen,
    initialCustomerName,
    initialCustomerPhone,
    initialCustomerAddress,
    initialPostalCode,
  ]);

  if (!isOpen) return null;

  const productMap = new Map(products.map((p) => [p.id, p]));
  let subtotal = 0;
  for (const item of cart) {
    const prod = productMap.get(item.productId);
    if (!prod) continue;
    subtotal += prod.price * item.quantity;
  }
  const shippingCost = subtotal >= 1500000 ? 0 : 65000;
  const grandTotal = subtotal + shippingCost;

  const handleShippingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    if (customerName.trim().length < 3) {
      setErrorMsg('لطفاً نام و نام خانوادگی معتبر وارد کنید.');
      return;
    }
    if (!/^09\d{9}$/.test(customerPhone.trim())) {
      setErrorMsg('شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود.');
      return;
    }
    if (customerAddress.trim().length < 8) {
      setErrorMsg('لطفاً آدرس کامل پستی را وارد نمایید.');
      return;
    }
    setStep('gateway');
  };

  const handleRequestOtp = () => {
    const code = String(Math.floor(100000 + Math.random() * 899999));
    setGeneratedOtp(code);
    setOtp(code);
    setErrorMsg(null);
  };

  const handlePaySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    const digits = cardNumber.replace(/\D/g, '');
    if (digits.length !== 16) {
      setErrorMsg('شماره کارت بانکی باید دقیقاً ۱۶ رقم باشد.');
      return;
    }
    if (cvv2.trim().length < 3 || cvv2.trim().length > 4) {
      setErrorMsg('کد CVV2 معتبر وارد نمایید.');
      return;
    }
    if (otp.trim().length < 5) {
      setErrorMsg('لطفاً رمز پویا را دریافت و وارد نمایید.');
      return;
    }

    setIsSubmitting(true);
    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (authToken) {
        headers.Authorization = `Bearer ${authToken}`;
      }
      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          customerName: customerName.trim(),
          customerPhone: customerPhone.trim(),
          customerAddress: customerAddress.trim(),
          postalCode: postalCode.trim(),
          cardNumber: digits,
          items: cart,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        setErrorMsg(data.error || 'خطا در پردازش تراکنش آنلاین.');
        setIsSubmitting(false);
        return;
      }

      setCompletedOrder(data.order);
      setStep('receipt');
      onOrderCompleted(data.order);
    } catch {
      setErrorMsg('ارتباط با سرور پرداخت برقرار نشد. دوباره تلاش کنید.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetAndClose = () => {
    setStep('shipping');
    setErrorMsg(null);
    setCompletedOrder(null);
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      onClick={resetAndClose}
    >
      <div
        className="bg-white border border-sky-100 rounded-2xl max-w-xl w-full overflow-hidden shadow-2xl my-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Modal Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-sky-600 text-white">
          <div className="flex items-center gap-2">
            {step === 'shipping' && <Truck className="w-5 h-5" />}
            {step === 'gateway' && <Lock className="w-5 h-5" />}
            {step === 'receipt' && <CheckCircle2 className="w-5 h-5" />}
            <h2 className="text-base font-extrabold">
              {step === 'shipping' && 'مرحله ۱: اطلاعات ارسال سفارش'}
              {step === 'gateway' && 'مرحله ۲: درگاه پرداخت آنلاین شتابی'}
              {step === 'receipt' && 'تراکنش موفق · رسید پرداخت آنلاین'}
            </h2>
          </div>
          <button
            type="button"
            onClick={resetAndClose}
            className="p-1.5 rounded-lg text-sky-100 hover:text-white hover:bg-sky-700 cursor-pointer"
            aria-label="بستن"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          {errorMsg && (
            <div className="mb-4 p-3 rounded-xl bg-red-50 border border-red-200 text-xs font-semibold text-red-700">
              {errorMsg}
            </div>
          )}

          {step === 'shipping' && (
            <form onSubmit={handleShippingSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    نام و نام خانوادگی *
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="مثلاً: علی محمدی"
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    شماره موبایل *
                  </label>
                  <input
                    type="tel"
                    required
                    dir="ltr"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="09123456789"
                    className="w-full px-3.5 py-2.5 text-sm font-mono-num text-left border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  آدرس کامل پستی *
                </label>
                <textarea
                  required
                  rows={2}
                  value={customerAddress}
                  onChange={(e) => setCustomerAddress(e.target.value)}
                  placeholder="استان، شهر، خیابان، پلاک، واحد"
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  کد پستی ۱۰ رقمی
                </label>
                <input
                  type="text"
                  dir="ltr"
                  value={postalCode}
                  onChange={(e) => setPostalCode(e.target.value)}
                  placeholder="1415512345"
                  className="w-full px-3.5 py-2.5 text-sm font-mono-num text-left border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="p-3.5 rounded-xl bg-sky-50 border border-sky-100 flex items-center justify-between text-xs">
                <span className="text-slate-700 font-semibold">مبلغ نهایی قابل پرداخت:</span>
                <span className="text-sm font-extrabold text-red-600 tabular-nums">
                  {formatToman(grandTotal)}
                </span>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-bold transition-colors cursor-pointer"
              >
                انتقال به درگاه پرداخت آنلاین
              </button>
            </form>
          )}

          {step === 'gateway' && (
            <form onSubmit={handlePaySubmit} className="space-y-4">
              <div className="p-4 rounded-xl bg-sky-50 border border-sky-200 flex items-center justify-between">
                <div>
                  <p className="text-xs font-bold text-slate-700">پذیرنده: فروشگاه خضری</p>
                  <p className="text-xs text-slate-500 mt-0.5">
                    هزینه ارسال: {shippingCost === 0 ? 'رایگان' : formatToman(shippingCost)}
                  </p>
                </div>
                <div className="text-left">
                  <p className="text-[11px] text-slate-500">مبلغ تراکنش</p>
                  <p className="text-base font-extrabold text-red-600 tabular-nums">
                    {formatToman(grandTotal)}
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  شماره کارت بانکی (۱۶ رقمی)
                </label>
                <div className="relative">
                  <CreditCard className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    dir="ltr"
                    maxLength={19}
                    required
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    className="w-full pr-9 pl-4 py-2.5 text-sm font-mono-num text-center tracking-widest border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">CVV2</label>
                  <input
                    type="password"
                    dir="ltr"
                    maxLength={4}
                    required
                    value={cvv2}
                    onChange={(e) => setCvv2(e.target.value)}
                    className="w-full px-3 py-2.5 text-sm font-mono-num text-center border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">ماه انقضا</label>
                  <input
                    type="text"
                    dir="ltr"
                    maxLength={2}
                    required
                    value={expMonth}
                    onChange={(e) => setExpMonth(e.target.value)}
                    className="w-full px-3 py-2.5 text-sm font-mono-num text-center border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">سال انقضا</label>
                  <input
                    type="text"
                    dir="ltr"
                    maxLength={2}
                    required
                    value={expYear}
                    onChange={(e) => setExpYear(e.target.value)}
                    className="w-full px-3 py-2.5 text-sm font-mono-num text-center border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  رمز دوم (پویا)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    dir="ltr"
                    required
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    placeholder="رمز ۶ رقمی"
                    className="flex-1 px-3.5 py-2.5 text-sm font-mono-num text-center border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                  <button
                    type="button"
                    onClick={handleRequestOtp}
                    className="px-4 py-2.5 text-xs font-bold text-sky-800 bg-sky-100 hover:bg-sky-200 rounded-xl transition-colors whitespace-nowrap shrink-0 cursor-pointer"
                  >
                    دریافت رمز پویا
                  </button>
                </div>
                {generatedOtp && (
                  <p className="text-[11px] text-sky-700 mt-1.5">
                    رمز پویای پیامک‌شده:{' '}
                    <span className="font-mono-num font-bold">{generatedOtp}</span>
                  </p>
                )}
              </div>

              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setStep('shipping')}
                  className="px-4 py-3 text-sm font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors cursor-pointer"
                >
                  بازگشت
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 py-3 px-4 rounded-xl bg-red-600 hover:bg-red-700 disabled:bg-red-400 text-white text-sm font-bold inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>{isSubmitting ? 'در حال تایید تراکنش...' : 'پرداخت آنلاین و ثبت سفارش'}</span>
                </button>
              </div>
            </form>
          )}

          {step === 'receipt' && completedOrder && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-sky-50 border border-sky-200 text-center">
                <CheckCircle2 className="w-10 h-10 text-sky-600 mx-auto mb-2" />
                <h3 className="text-base font-extrabold text-slate-900">
                  پرداخت آنلاین با موفقیت انجام شد
                </h3>
                <p className="text-xs text-slate-600 mt-1">
                  موجودی انبار به صورت خودکار به‌روزرسانی شد و سفارش شما در صف ارسال قرار گرفت.
                </p>
              </div>

              <div className="rounded-xl border border-slate-200 p-4 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">شماره سفارش:</span>
                  <span className="font-mono-num font-bold text-slate-900">{completedOrder.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">کد رهگیری پرداخت:</span>
                  <span className="font-mono-num font-bold text-sky-700">
                    {completedOrder.trackingCode}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">تاریخ و زمان:</span>
                  <span className="font-medium text-slate-900">
                    {formatDateTimeFa(completedOrder.createdAt)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">شماره کارت پرداختی:</span>
                  <span className="font-mono-num text-slate-900" dir="ltr">
                    ****-****-****-{completedOrder.cardLast4}
                  </span>
                </div>
                <div className="flex justify-between pt-2 border-t border-slate-100 text-sm font-extrabold">
                  <span className="text-slate-900">مبلغ پرداخت‌شده:</span>
                  <span className="text-red-600 tabular-nums">
                    {formatToman(completedOrder.finalTotal)}
                  </span>
                </div>
              </div>

              <div className="rounded-xl border border-slate-200 p-3 max-h-40 overflow-y-auto space-y-1.5">
                <p className="text-xs font-bold text-slate-700 mb-1">اقلام سفارش:</p>
                {completedOrder.items.map((it) => (
                  <div key={it.productId} className="flex justify-between text-xs text-slate-600">
                    <span className="truncate max-w-[260px]">
                      {it.productName} × {toPersianDigits(it.quantity)}
                    </span>
                    <span className="tabular-nums font-semibold text-slate-900">
                      {formatToman(it.lineTotal)}
                    </span>
                  </div>
                ))}
              </div>

              <div className="flex gap-3">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-50 inline-flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-4 h-4" />
                  <span>چاپ رسید</span>
                </button>
                <button
                  type="button"
                  onClick={resetAndClose}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-sm font-bold cursor-pointer"
                >
                  بازگشت به فروشگاه
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

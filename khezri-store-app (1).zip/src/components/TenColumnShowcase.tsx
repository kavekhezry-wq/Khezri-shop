import { CheckCircle2, ChevronDown, Plus, XCircle } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { Category, Product } from '../types/store';
import { sanitizeImageUrl } from '../utils/imageHelpers';
import { formatToman, normalizePersianSearch, toPersianDigits } from '../utils/storeHelpers';
import { CategorySymbol } from './CategorySymbol';

function ProductThumbOrSymbol({
  imageUrl,
  iconKey,
  name,
  isOutOfStock,
}: {
  imageUrl?: string;
  iconKey?: string;
  name: string;
  isOutOfStock: boolean;
}) {
  const [failed, setFailed] = useState(false);
  const safeSrc = sanitizeImageUrl(imageUrl);

  if (safeSrc && !failed) {
    return (
      <img
        src={safeSrc}
        alt={name}
        loading="lazy"
        onError={() => setFailed(true)}
        className={`w-6 h-6 rounded object-cover shrink-0 border ${
          isOutOfStock ? 'border-slate-200 opacity-70' : 'border-sky-200'
        }`}
      />
    );
  }

  return (
    <span
      className={`w-5 h-5 rounded flex items-center justify-center shrink-0 ${
        isOutOfStock ? 'bg-slate-100' : 'bg-sky-50'
      }`}
    >
      <CategorySymbol iconKey={iconKey} className="w-3 h-3" />
    </span>
  );
}

interface TenColumnShowcaseProps {
  categories: Category[];
  products: Product[];
  searchQuery: string;
  cartMap: Map<string, number>;
  onAddToCart: (productId: string) => void;
  onSelectProduct: (product: Product) => void;
}

export function TenColumnShowcase({
  categories,
  products,
  searchQuery,
  cartMap,
  onAddToCart,
  onSelectProduct,
}: TenColumnShowcaseProps) {
  // All 10 columns start collapsed by default
  const [expandedColumns, setExpandedColumns] = useState<Record<string, boolean>>({});

  const toggleColumn = (categoryId: string) => {
    setExpandedColumns((prev) => ({
      ...prev,
      [categoryId]: !prev[categoryId],
    }));
  };

  const sortedCategories = useMemo(
    () => categories.slice().sort((a, b) => a.columnOrder - b.columnOrder).slice(0, 10),
    [categories],
  );

  const normalizedQuery = normalizePersianSearch(searchQuery);
  const isSearching = normalizedQuery.length > 0;

  const productsByCategory = useMemo(() => {
    const map = new Map<string, Product[]>();
    for (const cat of sortedCategories) {
      map.set(cat.id, []);
    }
    for (const prod of products) {
      const list = map.get(prod.categoryId);
      if (!list) continue;

      if (isSearching) {
        const hay = normalizePersianSearch(`${prod.name} ${prod.brand} ${prod.sku}`);
        if (!hay.includes(normalizedQuery)) continue;
      }

      if (list.length < 20) {
        list.push(prod);
      }
    }
    return map;
  }, [products, sortedCategories, isSearching, normalizedQuery]);

  return (
    <section id="catalog-matrix" className="py-4 sm:py-6">
      <div className="max-w-[1600px] mx-auto px-2 sm:px-4">
        <div className="overflow-x-auto matrix-scroll pb-2">
          <div className="min-w-[1360px] grid grid-cols-10 gap-2 items-start">
            {sortedCategories.map((category) => {
              const columnProducts = productsByCategory.get(category.id) ?? [];
              const inStockTotal = columnProducts.filter((p) => p.stock > 0).length;
              const outOfStockTotal = columnProducts.filter((p) => p.stock <= 0).length;

              // When searching, auto-open columns that have matches and keep empty ones closed
              const isExpanded = isSearching
                ? columnProducts.length > 0
                : Boolean(expandedColumns[category.id]);

              return (
                <div
                  key={category.id}
                  className="flex flex-col bg-white border border-sky-200/90 rounded-xl overflow-hidden"
                >
                  {/* Collapsible Column Header with Downward Arrow */}
                  <button
                    type="button"
                    onClick={() => toggleColumn(category.id)}
                    aria-expanded={isExpanded}
                    className={`w-full text-right p-2.5 transition-colors cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-red-500 ${
                      isSearching && columnProducts.length === 0
                        ? 'bg-slate-200 text-slate-500'
                        : 'bg-sky-600 hover:bg-sky-700 text-white'
                    } ${isExpanded ? 'border-b border-sky-700' : ''}`}
                  >
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <span
                        className={`inline-flex items-center gap-1 text-[10px] font-mono-num ${
                          isSearching && columnProducts.length === 0
                            ? 'text-slate-500'
                            : 'text-sky-100'
                        }`}
                      >
                        <CategorySymbol iconKey={category.iconKey} className="w-3.5 h-3.5 shrink-0" />
                        <span>ستون {toPersianDigits(category.columnOrder)}</span>
                      </span>
                      <ChevronDown
                        className={`w-4 h-4 shrink-0 transition-transform duration-150 ${
                          isExpanded ? 'rotate-180' : 'rotate-0'
                        }`}
                      />
                    </div>

                    <h2
                      className="text-xs font-extrabold leading-tight truncate"
                      title={category.name}
                    >
                      {category.name}
                    </h2>

                    <div
                      className={`mt-1.5 flex items-center justify-between text-[10px] tabular-nums ${
                        isSearching && columnProducts.length === 0
                          ? 'text-slate-500'
                          : 'text-sky-100'
                      }`}
                    >
                      {isSearching ? (
                        <span>{toPersianDigits(columnProducts.length)} مورد یافت شد</span>
                      ) : (
                        <>
                          <span>{toPersianDigits(inStockTotal)} موجود</span>
                          <span>{toPersianDigits(outOfStockTotal)} ناموجود</span>
                        </>
                      )}
                    </div>
                  </button>

                  {/* Product Rows — Shown When Expanded or Matching Search */}
                  {isExpanded && (
                    <div className="p-1.5 flex flex-col gap-1.5 bg-slate-50/70">
                      {columnProducts.map((product, idx) => {
                        const inCart = cartMap.get(product.id) ?? 0;
                        const isOutOfStock = product.stock <= 0;
                        const canAdd = !isOutOfStock && inCart < product.stock;

                        return (
                          <article
                            key={product.id}
                            className={`bg-white border rounded-lg p-2 transition-all duration-150 ${
                              isOutOfStock
                                ? 'border-slate-200/80 bg-slate-50/70'
                                : 'border-slate-200 hover:border-sky-400 hover:shadow-xs'
                            }`}
                          >
                            {/* Row Number & Category Symbol */}
                            <div className="flex items-center justify-between gap-1 mb-1">
                              <button
                                type="button"
                                onClick={() => onSelectProduct(product)}
                                className={`inline-flex items-center gap-1 text-[10px] font-mono-num cursor-pointer ${
                                  isOutOfStock ? 'text-slate-400' : 'text-sky-700'
                                }`}
                                title={product.brand}
                              >
                                <ProductThumbOrSymbol
                                  imageUrl={product.imageUrl}
                                  iconKey={category.iconKey}
                                  name={product.name}
                                  isOutOfStock={isOutOfStock}
                                />
                                <span>{toPersianDigits(idx + 1)}</span>
                              </button>
                            </div>

                            {/* Product Name */}
                            <button
                              type="button"
                              onClick={() => onSelectProduct(product)}
                              className="text-right w-full text-[11px] font-bold text-slate-900 hover:text-sky-700 leading-snug line-clamp-2 min-h-[1.9rem] mb-1 cursor-pointer"
                              title={product.name}
                            >
                              {product.name}
                            </button>

                            {/* In-Stock / Out-of-Stock Indicator */}
                            <div className="mb-1">
                              {isOutOfStock ? (
                                <div className="flex items-center gap-1 text-[10px] font-bold text-red-600">
                                  <XCircle className="w-3 h-3 shrink-0" />
                                  <span>ناموجود</span>
                                </div>
                              ) : (
                                <div className="flex items-center gap-1 text-[10px] font-semibold text-sky-700 tabular-nums">
                                  <CheckCircle2 className="w-3 h-3 shrink-0" />
                                  <span>موجود ({toPersianDigits(product.stock)})</span>
                                </div>
                              )}
                            </div>

                            {/* Price */}
                            <p className="text-[11px] font-extrabold text-slate-900 tabular-nums mb-1.5 truncate">
                              {formatToman(product.price)}
                            </p>

                            {/* Quick Buy Button */}
                            <button
                              type="button"
                              disabled={!canAdd}
                              onClick={() => onAddToCart(product.id)}
                              className={`w-full py-1 px-1.5 rounded text-[10px] font-bold flex items-center justify-center gap-1 transition-colors cursor-pointer disabled:cursor-not-allowed ${
                                isOutOfStock
                                  ? 'bg-slate-100 text-slate-400'
                                  : canAdd
                                    ? 'bg-red-600 hover:bg-red-700 text-white'
                                    : 'bg-sky-100 text-sky-800'
                              }`}
                            >
                              {isOutOfStock ? (
                                <span>ناموجود</span>
                              ) : !canAdd ? (
                                <span>در سبد ({toPersianDigits(inCart)})</span>
                              ) : (
                                <>
                                  <Plus className="w-3 h-3 shrink-0" />
                                  <span>
                                    {inCart > 0
                                      ? `در سبد (${toPersianDigits(inCart)})`
                                      : 'خرید آنلاین'}
                                  </span>
                                </>
                              )}
                            </button>
                          </article>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}

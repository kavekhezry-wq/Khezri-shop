import {
  Check,
  ChevronDown,
  Clock,
  Copy,
  Edit3,
  ImagePlus,
  KeyRound,
  LogOut,
  MessageSquare,
  Package,
  Phone,
  Plus,
  RefreshCw,
  Save,
  Search,
  Send,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import type { Category, OtpRequestRecord, Product } from '../types/store';
import { compressImageToDataUrl, sanitizeImageUrl } from '../utils/imageHelpers';
import {
  formatDateTimeFa,
  formatToman,
  normalizePersianSearch,
  toPersianDigits,
} from '../utils/storeHelpers';
import { CategorySymbol } from './CategorySymbol';

interface AdminPanelProps {
  categories: Category[];
  products: Product[];
  adminToken: string;
  envManaged: boolean;
  onRefreshStore: () => Promise<void>;
  onNotify: (msg: string) => void;
  onLogout: () => void;
  onAuthExpired: () => void;
}

interface RowDraft {
  name: string;
  categoryId: string;
  price: string;
  stock: string;
  imageUrl: string;
}

export function AdminPanel({
  categories,
  products,
  adminToken,
  envManaged,
  onRefreshStore,
  onNotify,
  onLogout,
  onAuthExpired,
}: AdminPanelProps) {
  const [adminTab, setAdminTab] = useState<'products' | 'otp'>('products');

  // Customer OTP queue state
  const [otpRequests, setOtpRequests] = useState<OtpRequestRecord[]>([]);
  const [adminSmsReceiver, setAdminSmsReceiver] = useState('09146265841');
  const [smsGatewayConfigured, setSmsGatewayConfigured] = useState(false);
  const [loadingOtps, setLoadingOtps] = useState(false);
  const [copiedOtpId, setCopiedOtpId] = useState<string | null>(null);

  // Fast Product Management state
  const [prodSearch, setProdSearch] = useState('');
  const [prodCatFilter, setProdCatFilter] = useState<string>('all');
  const [prodStockFilter, setProdStockFilter] = useState<'all' | 'in_stock' | 'out_of_stock'>('all');
  const [openCategories, setOpenCategories] = useState<Record<string, boolean>>({});
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Compact Photo Modal state
  const [photoModalProduct, setPhotoModalProduct] = useState<Product | null>(null);
  const [photoDraftUrl, setPhotoDraftUrl] = useState('');
  const [photoBusy, setPhotoBusy] = useState(false);

  // Change Password Modal state
  const [isPassModalOpen, setIsPassModalOpen] = useState(false);
  const [currPass, setCurrPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmNewPass, setConfirmNewPass] = useState('');
  const [passError, setPassError] = useState<string | null>(null);
  const [savingPass, setSavingPass] = useState(false);

  // Per-row inline edits & saving status
  const [rowDrafts, setRowDrafts] = useState<Record<string, RowDraft>>({});
  const [savingRowId, setSavingRowId] = useState<string | null>(null);
  const [savedRowId, setSavedRowId] = useState<string | null>(null);

  // Product Modal Form state
  const [formName, setFormName] = useState('');
  const [formSku, setFormSku] = useState('');
  const [formCategoryId, setFormCategoryId] = useState(categories[0]?.id ?? 'gcat-1');
  const [formBrand, setFormBrand] = useState('');
  const [formPrice, setFormPrice] = useState('');
  const [formStock, setFormStock] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formImageUrl, setFormImageUrl] = useState('');

  const fetchOtpRequests = useCallback(
    async (silent = false) => {
      if (!silent) setLoadingOtps(true);
      try {
        const res = await fetch('/api/admin/otp-requests', {
          headers: { Authorization: `Bearer ${adminToken}` },
        });
        if (res.status === 401) {
          onAuthExpired();
          return;
        }
        if (res.ok) {
          const data = (await res.json()) as {
            adminSmsReceiver?: string;
            smsGatewayConfigured?: boolean;
            requests?: OtpRequestRecord[];
          };
          if (data.adminSmsReceiver) setAdminSmsReceiver(data.adminSmsReceiver);
          setSmsGatewayConfigured(Boolean(data.smsGatewayConfigured));
          setOtpRequests(data.requests ?? []);
        }
      } catch {
        // ignore transient network errors on background poll
      } finally {
        if (!silent) setLoadingOtps(false);
      }
    },
    [adminToken, onAuthExpired],
  );

  useEffect(() => {
    fetchOtpRequests(false);
  }, [fetchOtpRequests]);

  useEffect(() => {
    if (adminTab !== 'otp') return;
    const timer = setInterval(() => {
      fetchOtpRequests(true);
    }, 6000);
    return () => clearInterval(timer);
  }, [adminTab, fetchOtpRequests]);

  const pendingOtpCount = useMemo(
    () =>
      otpRequests.filter(
        (r) => r.status === 'pending' && new Date(r.expiresAt).getTime() > Date.now(),
      ).length,
    [otpRequests],
  );

  const handleDeleteOtpRequest = async (id: string) => {
    const res = await fetch(`/api/admin/otp-requests/${id}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${adminToken}` },
    });
    if (res.status === 401) {
      onAuthExpired();
      return;
    }
    if (res.ok) {
      setOtpRequests((prev) => prev.filter((r) => r.id !== id));
      onNotify('درخواست کد ورود حذف شد.');
    }
  };

  const handleCopyOtpSms = async (req: OtpRequestRecord) => {
    const smsText = `سلام ${req.customerName} عزیز، کد یکبار مصرف ورود شما به فروشگاه خضری: ${req.code}`;
    try {
      await navigator.clipboard.writeText(smsText);
      setCopiedOtpId(req.id);
      setTimeout(() => setCopiedOtpId((curr) => (curr === req.id ? null : curr)), 2000);
      onNotify('متن پیامک و کد ورود کپی شد.');
    } catch {
      onNotify(`کد ورود: ${req.code}`);
    }
  };

  const sortedCategories = useMemo(
    () => categories.slice().sort((a, b) => a.columnOrder - b.columnOrder),
    [categories],
  );

  const filteredProducts = useMemo(() => {
    const q = normalizePersianSearch(prodSearch);
    return products.filter((p) => {
      if (prodCatFilter !== 'all' && p.categoryId !== prodCatFilter) return false;
      if (prodStockFilter === 'in_stock' && p.stock <= 0) return false;
      if (prodStockFilter === 'out_of_stock' && p.stock > 0) return false;
      if (q) {
        const hay = normalizePersianSearch(`${p.name} ${p.sku} ${p.brand}`);
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [products, prodCatFilter, prodStockFilter, prodSearch]);

  const categoryCounts = useMemo(() => {
    const counts = new Map<string, { total: number; inStock: number; outOfStock: number }>();
    for (const c of sortedCategories) {
      counts.set(c.id, { total: 0, inStock: 0, outOfStock: 0 });
    }
    for (const p of products) {
      const entry = counts.get(p.categoryId);
      if (entry) {
        entry.total += 1;
        if (p.stock > 0) entry.inStock += 1;
        else entry.outOfStock += 1;
      }
    }
    return counts;
  }, [sortedCategories, products]);

  const groupedSections = useMemo(() => {
    const byCat = new Map<string, Product[]>();
    for (const p of filteredProducts) {
      const list = byCat.get(p.categoryId) ?? [];
      list.push(p);
      byCat.set(p.categoryId, list);
    }

    return sortedCategories
      .filter((c) => prodCatFilter === 'all' || c.id === prodCatFilter)
      .map((c) => ({
        category: c,
        items: byCat.get(c.id) ?? [],
      }))
      .filter((sec) => prodCatFilter !== 'all' || sec.items.length > 0 || !prodSearch.trim());
  }, [sortedCategories, filteredProducts, prodCatFilter, prodSearch]);

  const isFilteringActive = Boolean(prodSearch.trim()) || prodStockFilter !== 'all' || prodCatFilter !== 'all';

  const isCategoryOpen = (catId: string): boolean => {
    if (isFilteringActive) return true;
    return Boolean(openCategories[catId]);
  };

  const toggleCategoryOpen = (catId: string) => {
    setOpenCategories((prev) => ({
      ...prev,
      [catId]: !prev[catId],
    }));
  };

  const allExpanded = useMemo(
    () => sortedCategories.every((c) => Boolean(openCategories[c.id])),
    [sortedCategories, openCategories],
  );

  const handleToggleAllCategories = () => {
    const nextVal = !allExpanded;
    const nextState: Record<string, boolean> = {};
    for (const c of sortedCategories) {
      nextState[c.id] = nextVal;
    }
    setOpenCategories(nextState);
  };

  const getRowValues = (product: Product): RowDraft => {
    return (
      rowDrafts[product.id] ?? {
        name: product.name,
        categoryId: product.categoryId,
        price: String(product.price),
        stock: String(product.stock),
        imageUrl: product.imageUrl ?? '',
      }
    );
  };

  const updateRowDraft = (product: Product, patch: Partial<RowDraft>) => {
    setRowDrafts((prev) => {
      const current = prev[product.id] ?? {
        name: product.name,
        categoryId: product.categoryId,
        price: String(product.price),
        stock: String(product.stock),
        imageUrl: product.imageUrl ?? '',
      };
      return {
        ...prev,
        [product.id]: { ...current, ...patch },
      };
    });
  };

  const isRowDirty = (product: Product): boolean => {
    const draft = rowDrafts[product.id];
    if (!draft) return false;
    return (
      draft.name.trim() !== product.name ||
      draft.categoryId !== product.categoryId ||
      Number(draft.price) !== product.price ||
      Math.max(0, Math.floor(Number(draft.stock) || 0)) !== product.stock ||
      draft.imageUrl.trim() !== (product.imageUrl ?? '')
    );
  };

  // Save inline edits for a specific product row immediately to server
  const handleSaveRowChanges = async (product: Product) => {
    const draft = getRowValues(product);
    const trimmedName = draft.name.trim();
    const numericPrice = Number(draft.price);
    const numericStock = Math.max(0, Math.floor(Number(draft.stock) || 0));

    if (!trimmedName) {
      onNotify('نام کالا نمی‌تواند خالی باشد.');
      return;
    }
    if (Number.isNaN(numericPrice) || numericPrice < 0) {
      onNotify('قیمت واردشده نامعتبر است.');
      return;
    }

    setSavingRowId(product.id);
    try {
      const res = await fetch(`/api/products/${product.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({
          name: trimmedName,
          categoryId: draft.categoryId,
          price: Math.round(numericPrice),
          stock: numericStock,
          imageUrl: sanitizeImageUrl(draft.imageUrl) ?? '',
        }),
      });

      if (res.status === 401) {
        onAuthExpired();
        onNotify('نشست مدیریت منقضی شد. لطفاً دوباره وارد شوید.');
        return;
      }

      if (res.ok) {
        setRowDrafts((prev) => {
          const next = { ...prev };
          delete next[product.id];
          return next;
        });
        await onRefreshStore();
        setSavedRowId(product.id);
        setTimeout(() => {
          setSavedRowId((curr) => (curr === product.id ? null : curr));
        }, 1800);
        onNotify(`تغییرات «${trimmedName}» با موفقیت ذخیره شد.`);
      } else {
        onNotify('خطا در ذخیره تغییرات کالا.');
      }
    } finally {
      setSavingRowId(null);
    }
  };

  // Fast quick-stock toggle (charge 10 / mark out of stock)
  const handleQuickStockChange = async (product: Product, nextStock: number) => {
    const safeStock = Math.max(0, Math.floor(nextStock));
    const res = await fetch(`/api/products/${product.id}/quick`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
      },
      body: JSON.stringify({ stock: safeStock }),
    });
    if (res.status === 401) {
      onAuthExpired();
      onNotify('نشست مدیریت منقضی شد. لطفاً دوباره وارد شوید.');
      return;
    }
    if (res.ok) {
      setRowDrafts((prev) => {
        if (!prev[product.id]) return prev;
        return {
          ...prev,
          [product.id]: { ...prev[product.id], stock: String(safeStock) },
        };
      });
      await onRefreshStore();
      onNotify(`موجودی «${product.name}» به ${toPersianDigits(safeStock)} عدد تغییر یافت.`);
    }
  };

  const openAddProductModal = () => {
    setEditingProduct(null);
    setFormName('');
    setFormSku('');
    setFormCategoryId(prodCatFilter !== 'all' ? prodCatFilter : sortedCategories[0]?.id ?? 'gcat-1');
    setFormBrand('');
    setFormPrice('');
    setFormStock('10');
    setFormDescription('');
    setFormImageUrl('');
    setIsAddModalOpen(true);
  };

  const openEditProductModal = (product: Product) => {
    const draft = getRowValues(product);
    setEditingProduct(product);
    setFormName(draft.name);
    setFormSku(product.sku);
    setFormCategoryId(draft.categoryId);
    setFormBrand(product.brand);
    setFormPrice(draft.price);
    setFormStock(draft.stock);
    setFormDescription(product.description);
    setFormImageUrl(draft.imageUrl);
    setIsAddModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    const numericPrice = Number(formPrice);
    const numericStock = Number(formStock);
    if (!formName.trim() || Number.isNaN(numericPrice) || numericPrice < 0) return;

    const payload = {
      name: formName.trim(),
      sku: formSku.trim(),
      categoryId: formCategoryId,
      brand: formBrand.trim() || 'برند منتخب',
      price: numericPrice,
      stock: Number.isNaN(numericStock) ? 0 : Math.max(0, Math.floor(numericStock)),
      description: formDescription.trim(),
      imageUrl: sanitizeImageUrl(formImageUrl) ?? '',
    };

    const url = editingProduct ? `/api/products/${editingProduct.id}` : '/api/products';
    const method = editingProduct ? 'PUT' : 'POST';

    const res = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${adminToken}`,
      },
      body: JSON.stringify(payload),
    });

    if (res.status === 401) {
      onAuthExpired();
      onNotify('نشست مدیریت منقضی شد. لطفاً دوباره وارد شوید.');
      return;
    }

    if (res.ok) {
      if (editingProduct) {
        setRowDrafts((prev) => {
          const next = { ...prev };
          delete next[editingProduct.id];
          return next;
        });
      }
      setIsAddModalOpen(false);
      await onRefreshStore();
      onNotify(editingProduct ? 'تغییرات کالا با موفقیت ذخیره شد.' : 'کالای جدید به فروشگاه اضافه شد.');
    }
  };

  const handleDeleteProduct = async (productId: string) => {
    const res = await fetch(`/api/products/${productId}`, {
      method: 'DELETE',
      headers: { Authorization: `Bearer ${adminToken}` },
    });
    if (res.status === 401) {
      onAuthExpired();
      onNotify('نشست مدیریت منقضی شد. لطفاً دوباره وارد شوید.');
      return;
    }
    if (res.ok) {
      setConfirmDeleteId(null);
      setRowDrafts((prev) => {
        const next = { ...prev };
        delete next[productId];
        return next;
      });
      await onRefreshStore();
      onNotify('کالا با موفقیت از فروشگاه حذف شد.');
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPassError(null);
    if (newPass.trim().length < 6) {
      setPassError('رمز عبور جدید باید حداقل ۶ کاراکتر باشد.');
      return;
    }
    if (newPass.trim() !== confirmNewPass.trim()) {
      setPassError('رمز عبور جدید و تکرار آن یکسان نیستند.');
      return;
    }

    setSavingPass(true);
    try {
      const res = await fetch('/api/admin/change-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({
          currentPassword: currPass,
          newPassword: newPass.trim(),
        }),
      });
      if (res.status === 401) {
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        setPassError(data.error || 'رمز عبور فعلی صحیح نیست.');
        return;
      }
      if (!res.ok) {
        const data = (await res.json().catch(() => ({}))) as { error?: string };
        setPassError(data.error || 'خطا در تغییر رمز عبور.');
        return;
      }

      setIsPassModalOpen(false);
      setCurrPass('');
      setNewPass('');
      setConfirmNewPass('');
      onNotify('رمز عبور پنل مدیریت با موفقیت تغییر یافت.');
    } finally {
      setSavingPass(false);
    }
  };

  return (
    <div className="max-w-[1440px] mx-auto px-4 sm:px-6 py-5 space-y-4">
      {/* Compact Header */}
      <div className="bg-white border border-sky-100 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-50 border border-sky-100 text-sky-600 flex items-center justify-center shrink-0">
            <Package className="w-5 h-5" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-extrabold text-slate-900">
              مدیریت کالا و موجودی فروشگاه خضری
            </h1>
            <p className="text-xs text-slate-500 mt-0.5">
              دسته‌بندی مرتب اقلام در ۱۰ گروه؛ ویرایش مستقیم و ثبت فوری با دکمه «ذخیره تغییرات»
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {!envManaged && (
            <button
              type="button"
              onClick={() => {
                setPassError(null);
                setCurrPass('');
                setNewPass('');
                setConfirmNewPass('');
                setIsPassModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 text-xs font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>تغییر رمز</span>
            </button>
          )}

          <button
            type="button"
            onClick={onLogout}
            className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>خروج</span>
          </button>

          <button
            type="button"
            onClick={openAddProductModal}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>افزودن محصول جدید</span>
          </button>
        </div>

        {/* Admin Section Tabs */}
        <div className="w-full pt-3 mt-1 border-t border-slate-100 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => setAdminTab('products')}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              adminTab === 'products'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-sky-50 text-slate-700 hover:bg-sky-100'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>مدیریت کالاها</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setAdminTab('otp');
              fetchOtpRequests(false);
            }}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
              adminTab === 'otp'
                ? 'bg-sky-600 text-white shadow-xs'
                : 'bg-sky-50 text-slate-700 hover:bg-sky-100'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>کدهای ورود مشتریان</span>
            {pendingOtpCount > 0 && (
              <span
                className={`px-1.5 py-0.5 rounded-md font-mono-num text-[11px] ${
                  adminTab === 'otp' ? 'bg-red-600 text-white' : 'bg-red-600 text-white'
                }`}
              >
                {toPersianDigits(pendingOtpCount)}
              </span>
            )}
          </button>
        </div>
      </div>

      {adminTab === 'otp' ? (
        <div className="space-y-4">
          <div className="bg-white border border-sky-100 rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-sm font-extrabold text-slate-900">
                  درخواست‌های ورود مشتریان (پیامک کد یکبار مصرف)
                </h2>
                <span className="px-2.5 py-0.5 rounded-lg bg-sky-50 border border-sky-200 text-sky-800 text-[11px] font-bold">
                  گیرنده مدیر:{' '}
                  <span dir="ltr" className="font-mono-num">
                    {adminSmsReceiver}
                  </span>
                </span>
              </div>
              <p className="text-xs text-slate-500">
                {smsGatewayConfigured
                  ? `درگاه پیامکی متصل است و کدها هم‌زمان به شماره ${adminSmsReceiver} و این بخش ارسال می‌شوند.`
                  : `کدهای ۶ رقمی هر مشتری بلافاصله در این لیست نمایش داده می‌شوند تا از خط ${adminSmsReceiver} با یک لمس برای مشتری ارسال کنید.`}
              </p>
            </div>

            <button
              type="button"
              onClick={() => fetchOtpRequests(false)}
              disabled={loadingOtps}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 text-xs font-bold transition-colors cursor-pointer disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingOtps ? 'animate-spin' : ''}`} />
              <span>به‌روزرسانی لیست</span>
            </button>
          </div>

          {otpRequests.length === 0 ? (
            <div className="bg-white border border-sky-100 rounded-2xl p-10 text-center text-xs text-slate-500">
              هنوز هیچ درخواستی برای کد ورود یکبار مصرف ثبت نشده است.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {otpRequests.map((req) => {
                const isExpired =
                  req.status === 'pending' && new Date(req.expiresAt).getTime() <= Date.now();
                const smsBody = `سلام ${req.customerName} عزیز، کد یکبار مصرف ورود شما به فروشگاه خضری: ${req.code}`;
                const smsHref = `sms:${req.customerPhone}?body=${encodeURIComponent(smsBody)}`;

                return (
                  <div
                    key={req.id}
                    className={`bg-white border rounded-2xl p-4 flex flex-col justify-between gap-3 ${
                      req.status === 'pending' && !isExpired
                        ? 'border-sky-300 shadow-xs'
                        : 'border-slate-200 opacity-85'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm font-extrabold text-slate-900 truncate">
                            {req.customerName}
                          </span>
                          {req.status === 'verified' ? (
                            <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 text-[11px] font-bold">
                              وارد شد
                            </span>
                          ) : isExpired ? (
                            <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 text-[11px] font-bold">
                              منقضی شده
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 text-[11px] font-bold">
                              در انتظار ارسال کد
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-3 text-xs text-slate-600">
                          <span className="inline-flex items-center gap-1 font-mono-num" dir="ltr">
                            <Phone className="w-3.5 h-3.5 text-sky-600" />
                            {req.customerPhone}
                          </span>
                          <span className="inline-flex items-center gap-1 text-[11px] text-slate-400">
                            <Clock className="w-3 h-3" />
                            {formatDateTimeFa(req.createdAt)}
                          </span>
                        </div>
                      </div>

                      <div className="px-3 py-1.5 rounded-xl bg-sky-50 border border-sky-200 text-center shrink-0">
                        <div className="text-[10px] text-slate-500 font-semibold">کد یکبار مصرف</div>
                        <div
                          dir="ltr"
                          className="font-mono-num text-base font-extrabold tracking-widest text-red-600"
                        >
                          {req.code}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-xs">
                      <div className="flex flex-wrap items-center gap-2">
                        <a
                          href={smsHref}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold transition-colors"
                        >
                          <Send className="w-3.5 h-3.5" />
                          <span>ارسال پیامک به مشتری</span>
                        </a>

                        <button
                          type="button"
                          onClick={() => handleCopyOtpSms(req)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-50 hover:bg-sky-100 border border-sky-200 text-sky-800 font-bold cursor-pointer"
                        >
                          {copiedOtpId === req.id ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-600" />
                              <span>کپی شد</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5" />
                              <span>کپی پیامک و کد</span>
                            </>
                          )}
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleDeleteOtpRequest(req.id)}
                        className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-100 hover:bg-red-50 text-slate-600 hover:text-red-600 font-semibold cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>حذف</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        <>
          {/* Filters + Clean 10-Category Selector Bar */}
          <div className="bg-white border border-sky-100 rounded-2xl p-4 space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={prodSearch}
              onChange={(e) => setProdSearch(e.target.value)}
              placeholder="جستجوی نام، کد کالا یا برند..."
              className="w-full pr-9 pl-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-sky-500"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 p-1 bg-sky-50 rounded-xl">
              {(
                [
                  { id: 'all', label: 'همه' },
                  { id: 'in_stock', label: 'موجود' },
                  { id: 'out_of_stock', label: 'ناموجود' },
                ] as const
              ).map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setProdStockFilter(s.id)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg cursor-pointer transition-colors ${
                    prodStockFilter === s.id
                      ? 'bg-sky-600 text-white'
                      : 'text-slate-700 hover:bg-white'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            {!isFilteringActive && (
              <button
                type="button"
                onClick={handleToggleAllCategories}
                className="px-3 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer"
              >
                {allExpanded ? 'بستن همه دسته‌ها' : 'باز کردن همه دسته‌ها'}
              </button>
            )}
          </div>
        </div>

        {/* Tidy 10-Category Quick Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 pt-2 border-t border-slate-100">
          <button
            type="button"
            onClick={() => setProdCatFilter('all')}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
              prodCatFilter === 'all'
                ? 'bg-red-600 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-sky-50 hover:text-sky-800'
            }`}
          >
            <span>همه دسته‌ها</span>
            <span className="font-mono-num text-[11px] opacity-85">
              ({toPersianDigits(products.length)})
            </span>
          </button>

          {sortedCategories.map((cat) => {
            const count = categoryCounts.get(cat.id)?.total ?? 0;
            const active = prodCatFilter === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                onClick={() => {
                  setProdCatFilter(cat.id);
                  setOpenCategories((prev) => ({ ...prev, [cat.id]: true }));
                }}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  active
                    ? 'bg-sky-600 text-white'
                    : 'bg-sky-50/70 text-slate-700 border border-sky-100 hover:bg-sky-100'
                }`}
              >
                <CategorySymbol iconKey={cat.iconKey} className="w-3.5 h-3.5 shrink-0" />
                <span>{cat.name}</span>
                <span className="font-mono-num text-[11px] opacity-80">
                  ({toPersianDigits(count)})
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Organized Category Sections */}
      {groupedSections.length === 0 ? (
        <div className="bg-white border border-sky-100 rounded-2xl p-10 text-center text-xs text-slate-500">
          کالایی مطابق با جستجو یا فیلتر انتخاب‌شده یافت نشد.
        </div>
      ) : (
        <div className="space-y-3">
          {groupedSections.map(({ category, items }) => {
            const isOpen = isCategoryOpen(category.id);
            const inStockCount = items.filter((p) => p.stock > 0).length;
            const outStockCount = items.length - inStockCount;

            return (
              <section
                key={category.id}
                className="bg-white border border-sky-100 rounded-2xl overflow-hidden"
              >
                {/* Category Header */}
                <button
                  type="button"
                  onClick={() => toggleCategoryOpen(category.id)}
                  className="w-full px-4 py-3 bg-sky-50/80 hover:bg-sky-100/70 border-b border-sky-100 flex items-center justify-between gap-3 text-right transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="w-8 h-8 rounded-lg bg-white border border-sky-200 text-sky-600 flex items-center justify-center shrink-0">
                      <CategorySymbol iconKey={category.iconKey} className="w-4 h-4" />
                    </span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-bold text-sky-700 font-mono-num">
                          دسته {toPersianDigits(category.columnOrder)}
                        </span>
                        <h2 className="text-sm font-extrabold text-slate-900 truncate">
                          {category.name}
                        </h2>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 sm:gap-3 shrink-0 text-[11px] font-bold tabular-nums">
                    <span className="px-2 py-0.5 rounded-md bg-white border border-sky-200 text-slate-700">
                      {toPersianDigits(items.length)} کالا
                    </span>
                    <span className="hidden sm:inline text-sky-700">
                      {toPersianDigits(inStockCount)} موجود
                    </span>
                    {outStockCount > 0 && (
                      <span className="hidden sm:inline text-red-600">
                        {toPersianDigits(outStockCount)} ناموجود
                      </span>
                    )}
                    <ChevronDown
                      className={`w-4 h-4 text-sky-700 transition-transform duration-200 ${
                        isOpen ? 'rotate-180' : ''
                      }`}
                    />
                  </div>
                </button>

                {/* Clean Product Rows inside Category */}
                {isOpen && (
                  <div className="divide-y divide-slate-100">
                    {items.length === 0 ? (
                      <p className="py-6 text-center text-xs text-slate-400">
                        در این دسته‌بندی کالایی با فیلتر فعلی وجود ندارد.
                      </p>
                    ) : (
                      items.map((product) => {
                        const draft = getRowValues(product);
                        const draftStockNum = Math.max(0, Math.floor(Number(draft.stock) || 0));
                        const isOut = draftStockNum <= 0;
                        const dirty = isRowDirty(product);
                        const isSaving = savingRowId === product.id;
                        const isJustSaved = savedRowId === product.id;

                        return (
                          <div
                            key={product.id}
                            className={`px-4 py-3 grid grid-cols-1 xl:grid-cols-12 gap-3 items-center transition-colors ${
                              dirty ? 'bg-sky-50/40' : 'hover:bg-slate-50/70'
                            }`}
                          >
                            {/* Photo Option + Name, Code & Status */}
                            <div className="xl:col-span-4 space-y-1.5">
                              <div className="flex items-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => {
                                    setPhotoModalProduct(product);
                                    setPhotoDraftUrl(draft.imageUrl);
                                  }}
                                  title={draft.imageUrl ? 'تغییر یا حذف عکس کالا' : 'افزودن عکس کالا'}
                                  aria-label={`عکس ${product.name}`}
                                  className="w-9 h-9 rounded-lg border border-dashed border-sky-300 bg-sky-50/70 hover:bg-sky-100 text-sky-600 flex items-center justify-center shrink-0 overflow-hidden transition-colors cursor-pointer"
                                >
                                  {sanitizeImageUrl(draft.imageUrl) ? (
                                    <img
                                      src={sanitizeImageUrl(draft.imageUrl)}
                                      alt={product.name}
                                      className="w-full h-full object-cover"
                                    />
                                  ) : (
                                    <ImagePlus className="w-4 h-4" />
                                  )}
                                </button>

                                <input
                                  type="text"
                                  value={draft.name}
                                  onChange={(e) => updateRowDraft(product, { name: e.target.value })}
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') handleSaveRowChanges(product);
                                  }}
                                  aria-label={`نام ${product.name}`}
                                  className={`w-full px-3 py-1.5 rounded-lg text-xs font-bold text-slate-900 border transition-colors focus:outline-none focus:border-sky-500 ${
                                    dirty
                                      ? 'bg-white border-sky-300'
                                      : 'bg-slate-50/80 border-slate-200 focus:bg-white'
                                  }`}
                                />
                              </div>
                              <div className="flex flex-wrap items-center gap-2 text-[11px] px-0.5">
                                <span className="text-slate-500 font-mono-num">
                                  {product.sku} · {product.brand}
                                </span>
                                <span className="text-slate-300">|</span>
                                {isOut ? (
                                  <span className="text-red-600 font-bold">ناموجود در صفحه اصلی</span>
                                ) : (
                                  <span className="text-sky-700 font-bold">موجود</span>
                                )}
                                {dirty && (
                                  <span className="text-amber-600 font-semibold">
                                    · در انتظار ذخیره
                                  </span>
                                )}
                              </div>
                            </div>

                            {/* Category, Price, Stock Controls */}
                            <div className="xl:col-span-5 grid grid-cols-1 sm:grid-cols-3 gap-2.5 items-start">
                              <div>
                                <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                                  دسته‌بندی
                                </label>
                                <select
                                  value={draft.categoryId}
                                  onChange={(e) =>
                                    updateRowDraft(product, { categoryId: e.target.value })
                                  }
                                  aria-label={`دسته‌بندی ${product.name}`}
                                  className={`w-full px-2.5 py-1.5 rounded-lg text-xs font-medium text-slate-700 border focus:outline-none focus:border-sky-500 ${
                                    dirty
                                      ? 'bg-white border-sky-300'
                                      : 'bg-slate-50/80 border-slate-200 focus:bg-white'
                                  }`}
                                >
                                  {sortedCategories.map((c) => (
                                    <option key={c.id} value={c.id}>
                                      {c.name}
                                    </option>
                                  ))}
                                </select>
                              </div>

                              <div>
                                <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                                  قیمت (تومان)
                                </label>
                                <input
                                  type="number"
                                  min={0}
                                  value={draft.price}
                                  onChange={(e) =>
                                    updateRowDraft(product, { price: e.target.value })
                                  }
                                  onKeyDown={(e) => {
                                    if (e.key === 'Enter') handleSaveRowChanges(product);
                                  }}
                                  aria-label={`قیمت ${product.name}`}
                                  className={`w-full px-2.5 py-1.5 rounded-lg text-xs font-mono-num font-bold text-slate-900 border focus:outline-none focus:border-sky-500 ${
                                    dirty
                                      ? 'bg-white border-sky-300'
                                      : 'bg-slate-50/80 border-slate-200 focus:bg-white'
                                  }`}
                                />
                                <div className="text-[10px] text-slate-400 mt-0.5 tabular-nums">
                                  {formatToman(Math.max(0, Number(draft.price) || 0))}
                                </div>
                              </div>

                              <div>
                                <label className="block text-[10px] font-semibold text-slate-400 mb-1">
                                  موجودی انبار
                                </label>
                                <div className="flex items-center gap-1">
                                  <button
                                    type="button"
                                    onClick={() =>
                                      updateRowDraft(product, {
                                        stock: String(Math.max(0, draftStockNum - 1)),
                                      })
                                    }
                                    className="w-7 h-7 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-xs font-bold shrink-0 cursor-pointer"
                                  >
                                    -
                                  </button>
                                  <input
                                    type="number"
                                    min={0}
                                    value={draft.stock}
                                    onChange={(e) =>
                                      updateRowDraft(product, { stock: e.target.value })
                                    }
                                    onKeyDown={(e) => {
                                      if (e.key === 'Enter') handleSaveRowChanges(product);
                                    }}
                                    aria-label={`موجودی ${product.name}`}
                                    className={`w-14 text-center py-1 rounded-lg text-xs font-mono-num font-bold text-slate-900 border focus:outline-none focus:border-sky-500 ${
                                      dirty
                                        ? 'bg-white border-sky-300'
                                        : 'bg-slate-50/80 border-slate-200 focus:bg-white'
                                    }`}
                                  />
                                  <button
                                    type="button"
                                    onClick={() =>
                                      updateRowDraft(product, {
                                        stock: String(draftStockNum + 1),
                                      })
                                    }
                                    className="w-7 h-7 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-xs font-bold shrink-0 cursor-pointer"
                                  >
                                    +
                                  </button>
                                </div>
                                <button
                                  type="button"
                                  onClick={() =>
                                    handleQuickStockChange(product, product.stock <= 0 ? 10 : 0)
                                  }
                                  className={`mt-1 px-2 py-0.5 rounded text-[10px] font-semibold cursor-pointer ${
                                    product.stock <= 0
                                      ? 'bg-sky-100 text-sky-800 hover:bg-sky-200'
                                      : 'bg-slate-100 text-slate-600 hover:bg-red-50 hover:text-red-600'
                                  }`}
                                >
                                  {product.stock <= 0 ? 'شارژ ۱۰ تایی' : 'ناموجود کن'}
                                </button>
                              </div>
                            </div>

                            {/* Row Actions */}
                            <div className="xl:col-span-3 flex flex-wrap items-center xl:justify-end gap-1.5 text-xs">
                              <button
                                type="button"
                                disabled={isSaving}
                                onClick={() => handleSaveRowChanges(product)}
                                className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg font-bold transition-colors cursor-pointer disabled:opacity-60 ${
                                  isJustSaved
                                    ? 'bg-emerald-600 text-white'
                                    : dirty
                                      ? 'bg-sky-600 hover:bg-sky-700 text-white shadow-xs'
                                      : 'bg-sky-50 text-sky-800 hover:bg-sky-100 border border-sky-200'
                                }`}
                              >
                                {isJustSaved ? (
                                  <>
                                    <Check className="w-3.5 h-3.5" />
                                    <span>ذخیره شد</span>
                                  </>
                                ) : (
                                  <>
                                    <Save className="w-3.5 h-3.5" />
                                    <span>{isSaving ? 'در حال ذخیره...' : 'ذخیره تغییرات'}</span>
                                  </>
                                )}
                              </button>

                              <button
                                type="button"
                                onClick={() => openEditProductModal(product)}
                                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 font-semibold cursor-pointer"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                                <span>جزئیات</span>
                              </button>

                              {confirmDeleteId === product.id ? (
                                <div className="inline-flex items-center gap-1">
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteProduct(product.id)}
                                    className="px-2.5 py-1.5 rounded-lg bg-red-600 text-white font-bold cursor-pointer"
                                  >
                                    تایید حذف
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => setConfirmDeleteId(null)}
                                    className="px-2 py-1.5 rounded-lg bg-slate-100 text-slate-700 cursor-pointer"
                                  >
                                    انصراف
                                  </button>
                                </div>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => setConfirmDeleteId(product.id)}
                                  className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 font-semibold cursor-pointer"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  <span>حذف</span>
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                )}
              </section>
            );
          })}
        </div>
      )}
        </>
      )}

      {/* ADD / EDIT PRODUCT MODAL */}
      {isAddModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setIsAddModalOpen(false)}
        >
          <div
            className="bg-white border border-sky-100 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-5 py-4 bg-sky-600 text-white">
              <h3 className="text-sm font-extrabold">
                {editingProduct ? `ویرایش کالا: ${editingProduct.name}` : 'افزودن کالای جدید'}
              </h3>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 rounded-lg hover:bg-sky-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="p-5 space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">نام کالا *</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    ستون دسته‌بندی *
                  </label>
                  <select
                    value={formCategoryId}
                    onChange={(e) => setFormCategoryId(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-semibold border border-slate-200 rounded-xl bg-white focus:outline-none focus:border-sky-500"
                  >
                    {sortedCategories.map((c) => (
                      <option key={c.id} value={c.id}>
                        ستون {toPersianDigits(c.columnOrder)}: {c.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">برند</label>
                  <input
                    type="text"
                    value={formBrand}
                    onChange={(e) => setFormBrand(e.target.value)}
                    placeholder="مثلاً: طبیعت یا گلستان"
                    className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    قیمت (تومان) *
                  </label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-mono-num border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    موجودی انبار *
                  </label>
                  <input
                    type="number"
                    min={0}
                    required
                    value={formStock}
                    onChange={(e) => setFormStock(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-mono-num border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">کد SKU</label>
                  <input
                    type="text"
                    value={formSku}
                    onChange={(e) => setFormSku(e.target.value)}
                    placeholder="خودکار"
                    className="w-full px-3 py-2 text-xs font-mono-num border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">توضیحات کالا</label>
                <textarea
                  rows={2}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                />
              </div>

              {/* Compact Optional Photo Field */}
              <div className="p-3 rounded-xl bg-sky-50/60 border border-sky-100 space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-bold text-slate-700">عکس کالا (اختیاری)</span>
                  <div className="flex items-center gap-2">
                    <label className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-[11px] font-bold cursor-pointer">
                      <Upload className="w-3 h-3" />
                      <span>انتخاب عکس</span>
                      <input
                        type="file"
                        accept="image/png,image/jpeg,image/webp"
                        className="hidden"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          e.target.value = '';
                          if (!file) return;
                          try {
                            const dataUrl = await compressImageToDataUrl(file);
                            setFormImageUrl(dataUrl);
                          } catch (err) {
                            onNotify(err instanceof Error ? err.message : 'خطا در خواندن تصویر');
                          }
                        }}
                      />
                    </label>
                    {formImageUrl && (
                      <button
                        type="button"
                        onClick={() => setFormImageUrl('')}
                        className="px-2 py-1 rounded-lg bg-red-50 text-red-600 text-[11px] font-semibold cursor-pointer"
                      >
                        حذف عکس
                      </button>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2.5">
                  {sanitizeImageUrl(formImageUrl) && (
                    <img
                      src={sanitizeImageUrl(formImageUrl)}
                      alt={formName || 'پیش‌نمایش کالا'}
                      className="w-10 h-10 rounded-lg object-cover border border-sky-200 shrink-0 bg-white"
                    />
                  )}
                  <input
                    type="url"
                    value={formImageUrl.startsWith('data:') ? '' : formImageUrl}
                    onChange={(e) => setFormImageUrl(e.target.value)}
                    placeholder={
                      formImageUrl.startsWith('data:')
                        ? 'تصویر از فایل انتخاب شده است'
                        : 'یا لینک مستقیم عکس (https://...)'
                    }
                    className="w-full px-3 py-1.5 text-[11px] bg-white border border-slate-200 rounded-lg focus:outline-none focus:border-sky-500"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer"
                >
                  {editingProduct ? 'ذخیره تغییرات' : 'ثبت کالای جدید'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* COMPACT PRODUCT PHOTO PICKER MODAL */}
      {photoModalProduct && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setPhotoModalProduct(null)}
        >
          <div
            className="bg-white border border-sky-100 rounded-2xl max-w-sm w-full overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-4 py-3.5 bg-sky-600 text-white">
              <h3 className="text-xs sm:text-sm font-extrabold truncate">
                عکس کالا: {photoModalProduct.name}
              </h3>
              <button
                type="button"
                onClick={() => setPhotoModalProduct(null)}
                className="p-1 rounded-lg hover:bg-sky-700 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-4 space-y-3.5 text-xs">
              <div className="flex items-center justify-center">
                {sanitizeImageUrl(photoDraftUrl) ? (
                  <img
                    src={sanitizeImageUrl(photoDraftUrl)}
                    alt={photoModalProduct.name}
                    className="w-24 h-24 rounded-xl object-cover border border-sky-200 bg-slate-50"
                  />
                ) : (
                  <div className="w-24 h-24 rounded-xl border-2 border-dashed border-sky-200 bg-sky-50/50 text-sky-500 flex flex-col items-center justify-center gap-1">
                    <ImagePlus className="w-6 h-6" />
                    <span className="text-[10px] font-semibold">بدون عکس</span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2">
                <label className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold cursor-pointer">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{photoBusy ? 'در حال آماده‌سازی...' : 'انتخاب از گوشی / سیستم'}</span>
                  <input
                    type="file"
                    accept="image/png,image/jpeg,image/webp"
                    className="hidden"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      e.target.value = '';
                      if (!file) return;
                      setPhotoBusy(true);
                      try {
                        const dataUrl = await compressImageToDataUrl(file);
                        setPhotoDraftUrl(dataUrl);
                      } catch (err) {
                        onNotify(err instanceof Error ? err.message : 'خطا در پردازش عکس');
                      } finally {
                        setPhotoBusy(false);
                      }
                    }}
                  />
                </label>

                {photoDraftUrl && (
                  <button
                    type="button"
                    onClick={() => setPhotoDraftUrl('')}
                    className="px-3 py-2 rounded-xl bg-red-50 hover:bg-red-100 text-red-600 font-bold cursor-pointer"
                  >
                    حذف
                  </button>
                )}
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  یا لینک مستقیم عکس
                </label>
                <input
                  type="url"
                  value={photoDraftUrl.startsWith('data:') ? '' : photoDraftUrl}
                  onChange={(e) => setPhotoDraftUrl(e.target.value)}
                  placeholder={
                    photoDraftUrl.startsWith('data:')
                      ? 'عکس انتخاب‌شده آماده ذخیره است'
                      : 'https://example.com/photo.jpg'
                  }
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-sky-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setPhotoModalProduct(null)}
                  className="px-3.5 py-2 rounded-xl bg-slate-100 text-slate-700 font-semibold cursor-pointer"
                >
                  انصراف
                </button>
                <button
                  type="button"
                  disabled={photoBusy}
                  onClick={async () => {
                    const target = photoModalProduct;
                    const cleanUrl = sanitizeImageUrl(photoDraftUrl) ?? '';
                    const draft = getRowValues(target);
                    setPhotoBusy(true);
                    try {
                      const res = await fetch(`/api/products/${target.id}`, {
                        method: 'PUT',
                        headers: {
                          'Content-Type': 'application/json',
                          Authorization: `Bearer ${adminToken}`,
                        },
                        body: JSON.stringify({
                          name: draft.name.trim() || target.name,
                          categoryId: draft.categoryId || target.categoryId,
                          price: Math.max(0, Math.round(Number(draft.price) || target.price)),
                          stock: Math.max(0, Math.floor(Number(draft.stock) || 0)),
                          imageUrl: cleanUrl,
                        }),
                      });
                      if (res.status === 401) {
                        onAuthExpired();
                        onNotify('نشست مدیریت منقضی شد. لطفاً دوباره وارد شوید.');
                        setPhotoModalProduct(null);
                        return;
                      }
                      if (res.ok) {
                        setRowDrafts((prev) => {
                          if (!prev[target.id]) return prev;
                          return {
                            ...prev,
                            [target.id]: { ...prev[target.id], imageUrl: cleanUrl },
                          };
                        });
                        await onRefreshStore();
                        setPhotoModalProduct(null);
                        onNotify(
                          cleanUrl
                            ? `عکس «${target.name}» با موفقیت ثبت شد.`
                            : `عکس «${target.name}» حذف شد.`,
                        );
                      } else {
                        onNotify('خطا در ذخیره عکس کالا.');
                      }
                    } finally {
                      setPhotoBusy(false);
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold cursor-pointer disabled:opacity-60"
                >
                  ذخیره عکس
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CHANGE ADMIN PASSWORD MODAL */}
      {isPassModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setIsPassModalOpen(false)}
        >
          <div
            className="bg-white border border-sky-100 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-5 py-4 bg-sky-600 text-white">
              <h3 className="text-sm font-extrabold">تغییر رمز عبور مدیریت</h3>
              <button
                type="button"
                onClick={() => setIsPassModalOpen(false)}
                className="p-1 rounded-lg hover:bg-sky-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleChangePassword} className="p-5 space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  رمز عبور فعلی
                </label>
                <input
                  type="password"
                  required
                  value={currPass}
                  onChange={(e) => setCurrPass(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs font-mono-num border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  رمز عبور جدید (حداقل ۶ کاراکتر)
                </label>
                <input
                  type="password"
                  required
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs font-mono-num border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  تکرار رمز عبور جدید
                </label>
                <input
                  type="password"
                  required
                  value={confirmNewPass}
                  onChange={(e) => setConfirmNewPass(e.target.value)}
                  className="w-full px-3.5 py-2 text-xs font-mono-num border border-slate-200 rounded-xl focus:outline-none focus:border-sky-500"
                />
              </div>

              {passError && (
                <div className="px-3 py-2 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold">
                  {passError}
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsPassModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 text-slate-700 text-xs font-semibold cursor-pointer"
                >
                  انصراف
                </button>
                <button
                  type="submit"
                  disabled={savingPass}
                  className="px-5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer disabled:opacity-60"
                >
                  {savingPass ? 'در حال ثبت...' : 'ذخیره رمز جدید'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

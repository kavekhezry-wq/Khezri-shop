import { Eye, EyeOff, KeyRound, Lock, ShieldCheck } from 'lucide-react';
import { useEffect, useState } from 'react';

interface AdminAuthGateProps {
  onAuthenticated: (token: string, envManaged: boolean) => void;
  onBackToCustomerLogin?: () => void;
}

export function AdminAuthGate({
  onAuthenticated,
  onBackToCustomerLogin,
}: AdminAuthGateProps) {
  const [checking, setChecking] = useState(true);
  const [configured, setConfigured] = useState(true);
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function checkStatus() {
      try {
        const res = await fetch('/api/admin/status');
        if (res.ok && !cancelled) {
          const data = (await res.json()) as { configured: boolean };
          setConfigured(Boolean(data.configured));
        }
      } catch {
        if (!cancelled) {
          setErrorMsg('خطا در برقراری ارتباط با سرور.');
        }
      } finally {
        if (!cancelled) {
          setChecking(false);
        }
      }
    }
    checkStatus();
    return () => {
      cancelled = true;
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!configured) {
      if (password.trim().length < 6) {
        setErrorMsg('رمز عبور باید حداقل ۶ کاراکتر باشد.');
        return;
      }
      if (password.trim() !== confirmPassword.trim()) {
        setErrorMsg('رمز عبور و تکرار آن یکسان نیستند.');
        return;
      }
    } else if (!password) {
      setErrorMsg('لطفاً رمز عبور مدیریت را وارد کنید.');
      return;
    }

    setSubmitting(true);
    try {
      const endpoint = configured ? '/api/admin/login' : '/api/admin/setup';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password: configured ? password : password.trim() }),
      });

      const data = (await res.json().catch(() => ({}))) as {
        token?: string;
        envManaged?: boolean;
        error?: string;
      };

      if (!res.ok || !data.token) {
        setErrorMsg(data.error || 'احراز هویت ناموفق بود.');
        if (res.status === 409 && !configured) {
          setConfigured(true);
        }
        return;
      }

      setPassword('');
      setConfirmPassword('');
      onAuthenticated(data.token, Boolean(data.envManaged));
    } catch {
      setErrorMsg('خطا در ارتباط با سرور. لطفاً دوباره تلاش کنید.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-12 sm:py-16 space-y-4">
      <div className="bg-white border border-sky-100 rounded-2xl shadow-sm overflow-hidden">
        <div className="bg-sky-600 text-white px-6 py-5 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center shrink-0">
            {configured ? <Lock className="w-5 h-5" /> : <KeyRound className="w-5 h-5" />}
          </div>
          <div>
            <h1 className="text-base font-extrabold">
              {checking
                ? 'بررسی وضعیت امنیتی مدیریت...'
                : configured
                  ? 'ورود به پنل مدیریت'
                  : 'تعیین رمز عبور پنل مدیریت'}
            </h1>
            <p className="text-xs text-sky-100 mt-0.5">
              {configured
                ? 'برای دسترسی به مدیریت کالاها و کدهای ورود مشتریان رمز مدیریت را وارد کنید'
                : 'برای اولین ورود، یک رمز عبور اختصاصی جهت محافظت از پنل مدیریت تنظیم کنید'}
            </p>
          </div>
        </div>

        {checking ? (
          <div className="p-6 space-y-3">
            <div className="h-10 rounded-xl bg-slate-100 animate-pulse" />
            <div className="h-10 rounded-xl bg-slate-100 animate-pulse" />
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {configured ? 'رمز عبور مدیریت' : 'رمز عبور جدید (حداقل ۶ کاراکتر)'}
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  autoFocus
                  autoComplete={configured ? 'current-password' : 'new-password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-3.5 py-2.5 text-sm font-mono-num bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-sky-500"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((prev) => !prev)}
                  aria-label={showPassword ? 'مخفی کردن رمز' : 'نمایش رمز'}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {!configured && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  تکرار رمز عبور جدید
                </label>
                <input
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="new-password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 text-sm font-mono-num bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:bg-white focus:border-sky-500"
                />
              </div>
            )}

            {errorMsg && (
              <div className="px-3.5 py-2.5 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs font-semibold">
                {errorMsg}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-sm font-bold transition-colors cursor-pointer disabled:opacity-60"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>
                {submitting
                  ? 'در حال بررسی...'
                  : configured
                    ? 'ورود به مدیریت'
                    : 'ثبت رمز و ورود به مدیریت'}
              </span>
            </button>
          </form>
        )}
      </div>

      {onBackToCustomerLogin && (
        <div className="text-center">
          <button
            type="button"
            onClick={onBackToCustomerLogin}
            className="text-xs font-semibold text-slate-500 hover:text-sky-700 underline underline-offset-4 transition-colors cursor-pointer"
          >
            بازگشت به ورود مشتریان با شماره موبایل
          </button>
        </div>
      )}
    </div>
  );
}

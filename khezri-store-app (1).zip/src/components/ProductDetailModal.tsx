import { CheckCircle2, Minus, Plus, ShoppingBag, X, XCircle } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { Category, Product } from '../types/store';
import { sanitizeImageUrl } from '../utils/imageHelpers';
import { formatToman, toPersianDigits } from '../utils/storeHelpers';
import { CategorySymbol } from './CategorySymbol';

interface ProductDetailModalProps {
  product: Product | null;
  category: Category | undefined;
  cartQuantity: number;
  onClose: () => void;
  onAddToCart: (productId: string, quantity: number) => void;
}

export function ProductDetailModal({
  product,
  category,
  cartQuantity,
  onClose,
  onAddToCart,
}: ProductDetailModalProps) {
  const [qty, setQty] = useState(1);
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    setQty(1);
    setImgFailed(false);
  }, [product?.id]);

  if (!product) return null;

  const availableToAdd = Math.max(0, product.stock - cartQuantity);
  const isOutOfStock = product.stock <= 0;
  const safeImageSrc = sanitizeImageUrl(product.imageUrl);

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/50 backdrop-blur-xs flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white border border-sky-100 rounded-2xl max-w-lg w-full overflow-hidden shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 bg-sky-50/50">
          <div className="text-xs text-slate-600 flex items-center gap-2">
            <span>{category?.name ?? 'دسته‌بندی'}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono-num">{product.sku}</span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-white transition-colors cursor-pointer"
            aria-label="بستن"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {/* Lightweight Symbol / Optional Photo & Name Lockup */}
          <div className="flex items-start gap-4">
            {safeImageSrc && !imgFailed ? (
              <img
                src={safeImageSrc}
                alt={product.name}
                onError={() => setImgFailed(true)}
                className="w-20 h-20 rounded-2xl object-cover shrink-0 border border-sky-200 bg-white"
              />
            ) : (
              <div
                className={`w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 border ${
                  isOutOfStock
                    ? 'bg-slate-100 border-slate-200 text-slate-400'
                    : 'bg-sky-50 border-sky-200 text-sky-700'
                }`}
              >
                <CategorySymbol iconKey={category?.iconKey} className="w-8 h-8" />
              </div>
            )}

            <div className="min-w-0">
              <p className="text-xs font-medium text-sky-700 mb-1">برند: {product.brand}</p>
              <h3 className="text-lg font-extrabold text-slate-900 leading-snug">
                {product.name}
              </h3>
            </div>
          </div>

          <p className="text-sm text-slate-600 leading-relaxed">{product.description}</p>

          {/* Explicit Availability Status */}
          <div>
            {isOutOfStock ? (
              <div className="inline-flex items-center gap-1.5 text-sm font-bold text-red-600">
                <XCircle className="w-4 h-4 shrink-0" />
                <span>ناموجود در انبار</span>
              </div>
            ) : (
              <div className="inline-flex items-center gap-1.5 text-sm font-bold text-sky-700">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>موجود در انبار ({toPersianDigits(product.stock)} عدد)</span>
              </div>
            )}
          </div>

          {/* Pricing */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
            <div className="text-lg font-extrabold text-slate-900 tabular-nums">
              {formatToman(product.price)}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {!isOutOfStock && availableToAdd > 0 && (
              <div className="flex items-center border border-slate-200 rounded-xl bg-white">
                <button
                  type="button"
                  onClick={() => setQty((q) => Math.max(1, q - 1))}
                  className="p-2.5 text-slate-600 hover:text-slate-900 cursor-pointer"
                  aria-label="کاهش تعداد"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="px-3 text-sm font-bold tabular-nums">
                  {toPersianDigits(qty)}
                </span>
                <button
                  type="button"
                  onClick={() => setQty((q) => Math.min(availableToAdd, q + 1))}
                  className="p-2.5 text-slate-600 hover:text-slate-900 cursor-pointer"
                  aria-label="افزایش تعداد"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            )}

            <button
              type="button"
              disabled={isOutOfStock || availableToAdd <= 0}
              onClick={() => {
                onAddToCart(product.id, qty);
                onClose();
              }}
              className="flex-1 inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl text-sm font-bold text-white bg-red-600 hover:bg-red-700 disabled:bg-slate-200 disabled:text-slate-500 transition-colors cursor-pointer disabled:cursor-not-allowed"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>
                {isOutOfStock
                  ? 'کالا ناموجود است'
                  : availableToAdd <= 0
                    ? 'حداکثر موجودی در سبد شماست'
                    : 'افزودن به سبد خرید'}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

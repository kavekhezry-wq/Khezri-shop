import { Check, Copy, Download, Smartphone, X } from 'lucide-react';
import { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export function PWAInstallButton() {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showGuide, setShowGuide] = useState(false);
  const [copied, setCopied] = useState(false);

  // Hide when already running inside the installed standalone app
  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) return;
    }
    setShowGuide(true);
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(window.location.origin);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // ignore clipboard errors
    }
  };

  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 text-xs font-bold text-white bg-sky-600 hover:bg-sky-700 rounded-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Download className="w-3.5 h-3.5 shrink-0" />
        <span className="hidden sm:inline">نصب اپلیکیشن</span>
        <span className="sm:hidden">نصب اپ</span>
      </button>

      {showGuide && (
        <div
          className="fixed inset-0 z-50 bg-slate-950/55 backdrop-blur-xs flex items-center justify-center p-4"
          onClick={() => setShowGuide(false)}
        >
          <div
            className="bg-white border border-sky-100 rounded-2xl max-w-md w-full overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between px-5 py-4 bg-sky-600 text-white">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5" />
                <h3 className="text-sm font-extrabold">نصب فروشگاه خضری روی گوشی</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowGuide(false)}
                className="p-1 rounded-lg hover:bg-sky-700 cursor-pointer"
                aria-label="بستن"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 space-y-4 text-xs text-slate-700 leading-relaxed">
              <p className="text-slate-600">
                این فروشگاه به‌صورت کامل به <strong>وب‌اپلیکیشن پیشرونده (PWA)</strong> تبدیل شده است و بدون نیاز به فروشگاه‌های اپلیکیشن، مستقیم روی صفحه اصلی گوشی نصب می‌شود.
              </p>

              {isIOS ? (
                <div className="p-3.5 rounded-xl bg-sky-50 border border-sky-100 space-y-1.5">
                  <p className="font-extrabold text-sky-900">راهنمای نصب در آیفون و آیپد (Safari):</p>
                  <p>۱. لینک برنامه را در مرورگر <strong>Safari</strong> باز کنید.</p>
                  <p>۲. دکمه <strong>اشتراک‌گذاری (Share)</strong> در پایین صفحه را لمس کنید.</p>
                  <p>۳. گزینه <strong>Add to Home Screen</strong> را انتخاب و تایید کنید.</p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <div className="p-3.5 rounded-xl bg-sky-50 border border-sky-100 space-y-1">
                    <p className="font-extrabold text-sky-900">در گوشی اندروید (مرورگر Chrome):</p>
                    <p>۱. لینک برنامه را مستقیم در مرورگر Chrome گوشی باز کنید.</p>
                    <p>۲. منوی سه‌نقطه بالای مرورگر را بزنید و گزینه <strong>«نصب برنامه / Install app»</strong> یا <strong>«Add to Home screen»</strong> را انتخاب کنید.</p>
                  </div>
                  <div className="p-3.5 rounded-xl bg-red-50/70 border border-red-100 space-y-1">
                    <p className="font-extrabold text-red-800">در گوشی آیفون (مرورگر Safari):</p>
                    <p>دکمه <strong>Share</strong> را بزنید و گزینه <strong>Add to Home Screen</strong> را انتخاب کنید.</p>
                  </div>
                </div>
              )}

              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={handleCopyUrl}
                  className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copied ? 'لینک برنامه کپی شد' : 'کپی لینک برای باز کردن در گوشی'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setShowGuide(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold cursor-pointer"
                >
                  بستن
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

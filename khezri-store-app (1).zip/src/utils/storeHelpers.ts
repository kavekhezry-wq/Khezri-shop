import type { OrderStatus } from '../types/store';

export function formatToman(amount: number): string {
  const safeAmount = Math.max(0, Math.round(amount));
  return `${safeAmount.toLocaleString('fa-IR')} تومان`;
}

export function formatNumberFa(num: number): string {
  return num.toLocaleString('fa-IR');
}

export function toPersianDigits(value: string | number): string {
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(value).replace(/\d/g, (digit) => persianDigits[Number(digit)] ?? digit);
}

export function normalizePersianSearch(text: string): string {
  return text
    .trim()
    .toLowerCase()
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/ة/g, 'ه');
}

export function formatDateTimeFa(isoString: string): string {
  try {
    return new Intl.DateTimeFormat('fa-IR', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    }).format(new Date(isoString));
  } catch {
    return isoString;
  }
}

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  paid: 'پرداخت شده',
  preparing: 'در حال آماده‌سازی',
  shipped: 'ارسال شده',
  delivered: 'تحویل شده',
};

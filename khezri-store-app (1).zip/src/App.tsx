import { ShoppingBag } from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { AdminAuthGate } from './components/AdminAuthGate';
import { AdminPanel } from './components/AdminPanel';
import { CartDrawer } from './components/CartDrawer';
import { CustomerAuthGate } from './components/CustomerAuthGate';
import { CustomerSideDrawer } from './components/CustomerSideDrawer';
import { Header, type ActivePage } from './components/Header';
import { OfflineIndicator } from './components/OfflineIndicator';
import { OnlineCheckoutModal } from './components/OnlineCheckoutModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { TenColumnShowcase } from './components/TenColumnShowcase';
import type {
  CartItem,
  Category,
  CustomerLocation,
  CustomerUser,
  Order,
  Product,
} from './types/store';
import { toPersianDigits } from './utils/storeHelpers';

export default function App() {
  const [activePage, setActivePage] = useState<ActivePage>('storefront');
  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Auth tokens kept strictly in memory
  const [customerToken, setCustomerToken] = useState<string | null>(null);
  const [customerUser, setCustomerUser] = useState<CustomerUser | null>(null);
  const [adminToken, setAdminToken] = useState<string | null>(null);
  const [adminEnvManaged, setAdminEnvManaged] = useState(false);

  const activeAuthToken = adminToken ?? customerToken;

  // Modals & Drawers
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isSideDrawerOpen, setIsSideDrawerOpen] = useState(false);

  // Saved delivery locations per user
  const locationStorageKey = customerUser?.phone
    ? `khezri_locations_${customerUser.phone}`
    : adminToken
      ? 'khezri_locations_admin'
      : null;

  const [locations, setLocations] = useState<CustomerLocation[]>([]);
  const [selectedLocationId, setSelectedLocationId] = useState<string | null>(null);

  useEffect(() => {
    if (!locationStorageKey) {
      setLocations([]);
      setSelectedLocationId(null);
      return;
    }
    try {
      const saved = localStorage.getItem(locationStorageKey);
      if (saved) {
        const parsed = JSON.parse(saved) as {
          locations?: CustomerLocation[];
          selectedId?: string | null;
        };
        const list = Array.isArray(parsed.locations) ? parsed.locations : [];
        setLocations(list);
        setSelectedLocationId(
          parsed.selectedId && list.some((l) => l.id === parsed.selectedId)
            ? parsed.selectedId
            : list[0]?.id ?? null,
        );
      } else {
        setLocations([]);
        setSelectedLocationId(null);
      }
    } catch {
      setLocations([]);
      setSelectedLocationId(null);
    }
  }, [locationStorageKey]);

  const persistLocations = useCallback(
    (nextList: CustomerLocation[], nextSelectedId: string | null) => {
      if (!locationStorageKey) return;
      try {
        localStorage.setItem(
          locationStorageKey,
          JSON.stringify({ locations: nextList, selectedId: nextSelectedId }),
        );
      } catch {
        // ignore storage quota errors
      }
    },
    [locationStorageKey],
  );

  const activeLocation = useMemo(
    () => locations.find((l) => l.id === selectedLocationId) ?? locations[0] ?? null,
    [locations, selectedLocationId],
  );

  // Persistent Cart in localStorage
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('khezri_store_cart');
      return saved ? (JSON.parse(saved) as CartItem[]) : [];
    } catch {
      return [];
    }
  });

  // Subtle toast notification
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
  }, []);

  useEffect(() => {
    if (!toastMsg) return;
    const t = setTimeout(() => setToastMsg(null), 3200);
    return () => clearTimeout(t);
  }, [toastMsg]);

  useEffect(() => {
    try {
      localStorage.setItem('khezri_store_cart', JSON.stringify(cart));
    } catch {
      // ignore storage quota errors
    }
  }, [cart]);

  const fetchStorefront = useCallback(async () => {
    if (!activeAuthToken) {
      setCategories([]);
      setProducts([]);
      setLoading(false);
      setLoadError(null);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/storefront', {
        headers: { Authorization: `Bearer ${activeAuthToken}` },
      });
      if (res.status === 401) {
        setCustomerToken(null);
        setCustomerUser(null);
        setAdminToken(null);
        setAdminEnvManaged(false);
        setCategories([]);
        setProducts([]);
        setLoadError(null);
        return;
      }
      if (!res.ok) throw new Error('خطا در دریافت اطلاعات فروشگاه');
      const data = await res.json();
      setCategories(data.categories ?? []);
      setProducts(data.products ?? []);
      setLoadError(null);
    } catch {
      setLoadError('امکان اتصال به سرور فروشگاه وجود ندارد. لطفاً صفحه را تازه‌سازی کنید.');
    } finally {
      setLoading(false);
    }
  }, [activeAuthToken]);

  useEffect(() => {
    fetchStorefront();
  }, [fetchStorefront]);

  const cartMap = useMemo(() => {
    const m = new Map<string, number>();
    for (const item of cart) {
      m.set(item.productId, item.quantity);
    }
    return m;
  }, [cart]);

  const totalCartCount = useMemo(
    () => cart.reduce((acc, item) => acc + item.quantity, 0),
    [cart],
  );

  const handleAddToCart = useCallback(
    (productId: string, addQty = 1) => {
      const prod = products.find((p) => p.id === productId);
      if (!prod || prod.stock <= 0) {
        showToast('این کالا در حال حاضر ناموجود است.');
        return;
      }

      setCart((prev) => {
        const existing = prev.find((i) => i.productId === productId);
        const currentQty = existing?.quantity ?? 0;
        const nextQty = Math.min(prod.stock, currentQty + addQty);
        if (nextQty === currentQty) {
          showToast(`حداکثر موجودی «${prod.name}» در سبد خرید شما قرار دارد.`);
          return prev;
        }
        showToast(`«${prod.name}» به سبد خرید اضافه شد.`);
        if (existing) {
          return prev.map((i) => (i.productId === productId ? { ...i, quantity: nextQty } : i));
        }
        return [...prev, { productId, quantity: nextQty }];
      });
    },
    [products, showToast],
  );

  const handleUpdateCartQty = useCallback(
    (productId: string, qty: number) => {
      if (qty <= 0) {
        setCart((prev) => prev.filter((i) => i.productId !== productId));
        return;
      }
      const prod = products.find((p) => p.id === productId);
      const maxStock = prod ? prod.stock : qty;
      const clamped = Math.min(maxStock, qty);
      setCart((prev) =>
        prev.map((i) => (i.productId === productId ? { ...i, quantity: clamped } : i)),
      );
    },
    [products],
  );

  const handleRemoveCartItem = useCallback((productId: string) => {
    setCart((prev) => prev.filter((i) => i.productId !== productId));
  }, []);

  const handleNavigate = (page: ActivePage) => {
    setActivePage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOrderCompleted = async (order: Order) => {
    setCart([]);
    await fetchStorefront();
    showToast(`سفارش ${order.id} با موفقیت ثبت و پرداخت شد.`);
  };

  const handleAddLocation = useCallback(
    (locInput: Omit<CustomerLocation, 'id' | 'updatedAt'>) => {
      const nextLoc: CustomerLocation = {
        ...locInput,
        id: `loc-${Date.now()}`,
        updatedAt: new Date().toISOString(),
      };
      const nextList = [nextLoc, ...locations];
      setLocations(nextList);
      setSelectedLocationId(nextLoc.id);
      persistLocations(nextList, nextLoc.id);
      showToast(`مکان «${nextLoc.label}» ذخیره و انتخاب شد.`);
    },
    [locations, persistLocations, showToast],
  );

  const handleSelectLocation = useCallback(
    (id: string) => {
      setSelectedLocationId(id);
      persistLocations(locations, id);
      const found = locations.find((l) => l.id === id);
      if (found) {
        showToast(`مکان تحویل به «${found.label}» تغییر یافت.`);
      }
    },
    [locations, persistLocations, showToast],
  );

  const handleDeleteLocation = useCallback(
    (id: string) => {
      const nextList = locations.filter((l) => l.id !== id);
      const nextSelected =
        selectedLocationId === id ? nextList[0]?.id ?? null : selectedLocationId;
      setLocations(nextList);
      setSelectedLocationId(nextSelected);
      persistLocations(nextList, nextSelected);
      showToast('مکان انتخاب‌شده حذف شد.');
    },
    [locations, selectedLocationId, persistLocations, showToast],
  );

  const handleFullLogout = async () => {
    const cToken = customerToken;
    const aToken = adminToken;
    setIsSideDrawerOpen(false);
    setIsCartOpen(false);
    setIsCheckoutOpen(false);
    setSelectedProduct(null);
    setCustomerToken(null);
    setCustomerUser(null);
    setAdminToken(null);
    setAdminEnvManaged(false);
    setActivePage('storefront');

    if (cToken) {
      await fetch('/api/auth/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${cToken}` },
      }).catch(() => {});
    }
    if (aToken) {
      await fetch('/api/admin/logout', {
        method: 'POST',
        headers: { Authorization: `Bearer ${aToken}` },
      }).catch(() => {});
    }
    showToast('با موفقیت از برنامه خارج شدید.');
  };

  // Unauthenticated gate: must log in with Name + Phone + OTP (or Admin credentials)
  if (!activeAuthToken) {
    return (
      <div className="min-h-screen bg-slate-50 text-slate-900">
        {activePage === 'admin' ? (
          <AdminAuthGate
            onAuthenticated={(token, envManaged) => {
              setAdminToken(token);
              setAdminEnvManaged(envManaged);
              showToast('خوش آمدید. دسترسی پنل مدیریت فعال شد.');
            }}
            onBackToCustomerLogin={() => setActivePage('storefront')}
          />
        ) : (
          <CustomerAuthGate
            onAuthenticated={(token, customer) => {
              setCustomerToken(token);
              setCustomerUser(customer);
              setActivePage('storefront');
              showToast(`${customer.name} عزیز، خوش آمدید!`);
            }}
            onSwitchToAdmin={() => setActivePage('admin')}
          />
        )}

        <OfflineIndicator />

        {toastMsg && (
          <div
            role="status"
            className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-lg border border-sky-500/40 whitespace-nowrap"
          >
            {toastMsg}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <Header
        activePage={activePage}
        onNavigate={handleNavigate}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        isSideDrawerOpen={isSideDrawerOpen}
        onToggleSideDrawer={() => setIsSideDrawerOpen((prev) => !prev)}
        activeLocationLabel={activeLocation?.label}
        cartCount={totalCartCount}
      />

      <main className="flex-1 pb-8">
        {loading ? (
          <div className="max-w-[1600px] mx-auto px-2 sm:px-4 py-4">
            <div className="grid grid-cols-2 md:grid-cols-5 lg:grid-cols-10 gap-2">
              {Array.from({ length: 10 }).map((_, idx) => (
                <div key={idx} className="h-[720px] rounded-xl bg-slate-200/70 animate-pulse" />
              ))}
            </div>
          </div>
        ) : loadError ? (
          <div className="max-w-lg mx-auto my-20 p-6 bg-white border border-red-200 rounded-2xl text-center">
            <p className="text-sm font-bold text-red-600 mb-3">{loadError}</p>
            <button
              type="button"
              onClick={fetchStorefront}
              className="px-4 py-2 rounded-xl bg-sky-600 text-white text-xs font-bold cursor-pointer"
            >
              تلاش مجدد
            </button>
          </div>
        ) : activePage === 'storefront' ? (
          <TenColumnShowcase
            categories={categories}
            products={products}
            searchQuery={searchQuery}
            cartMap={cartMap}
            onAddToCart={(pid) => handleAddToCart(pid, 1)}
            onSelectProduct={setSelectedProduct}
          />
        ) : adminToken ? (
          <AdminPanel
            categories={categories}
            products={products}
            adminToken={adminToken}
            envManaged={adminEnvManaged}
            onRefreshStore={fetchStorefront}
            onNotify={showToast}
            onLogout={async () => {
              const token = adminToken;
              setAdminToken(null);
              setAdminEnvManaged(false);
              if (token) {
                await fetch('/api/admin/logout', {
                  method: 'POST',
                  headers: { Authorization: `Bearer ${token}` },
                }).catch(() => {});
              }
              showToast('از پنل مدیریت خارج شدید.');
            }}
            onAuthExpired={() => {
              setAdminToken(null);
              setAdminEnvManaged(false);
            }}
          />
        ) : (
          <AdminAuthGate
            onAuthenticated={(token, envManaged) => {
              setAdminToken(token);
              setAdminEnvManaged(envManaged);
              showToast('خوش آمدید. دسترسی پنل مدیریت فعال شد.');
            }}
            onBackToCustomerLogin={() => setActivePage('storefront')}
          />
        )}
      </main>

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        category={categories.find((c) => c.id === selectedProduct?.categoryId)}
        cartQuantity={selectedProduct ? cartMap.get(selectedProduct.id) ?? 0 : 0}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      {/* Shopping Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        categories={categories}
        products={products}
        onUpdateQty={handleUpdateCartQty}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={() => setCart([])}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
      />

      {/* Online Payment Gateway Modal */}
      <OnlineCheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cart={cart}
        products={products}
        authToken={activeAuthToken}
        initialCustomerName={customerUser?.name}
        initialCustomerPhone={customerUser?.phone}
        initialCustomerAddress={activeLocation?.address}
        initialPostalCode={activeLocation?.postalCode}
        onOrderCompleted={handleOrderCompleted}
      />

      {/* Collapsible Customer Side Drawer (Cart, Location, Support & Logout) */}
      <CustomerSideDrawer
        isOpen={isSideDrawerOpen}
        onClose={() => setIsSideDrawerOpen(false)}
        customerUser={customerUser}
        isAdmin={Boolean(adminToken)}
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        locations={locations}
        selectedLocationId={selectedLocationId}
        onSelectLocation={handleSelectLocation}
        onAddLocation={handleAddLocation}
        onDeleteLocation={handleDeleteLocation}
        onLogout={handleFullLogout}
        onNotify={showToast}
      />

      {/* Offline Connectivity Banner */}
      <OfflineIndicator />

      {/* Toast Notification */}
      {toastMsg && (
        <div
          role="status"
          className="fixed bottom-20 left-1/2 -translate-x-1/2 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-lg border border-sky-500/40 whitespace-nowrap"
        >
          {toastMsg}
        </div>
      )}
    </div>
  );
}

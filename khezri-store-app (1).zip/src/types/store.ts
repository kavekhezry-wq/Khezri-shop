export interface Category {
  id: string;
  name: string;
  slug: string;
  columnOrder: number;
  description: string;
  iconKey: string;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  categoryId: string;
  price: number;
  stock: number;
  description: string;
  brand: string;
  imageUrl?: string;
  salesCount: number;
  createdAt: string;
  updatedAt: string;
}

export interface OrderItem {
  productId: string;
  productName: string;
  categoryId: string;
  sku: string;
  quantity: number;
  unitPrice: number;
  lineTotal: number;
}

export type OrderStatus = 'paid' | 'preparing' | 'shipped' | 'delivered';

export interface Order {
  id: string;
  trackingCode: string;
  customerName: string;
  customerPhone: string;
  customerAddress: string;
  postalCode: string;
  paymentMethod: 'online_gateway';
  cardLast4: string;
  subtotal: number;
  shippingCost: number;
  finalTotal: number;
  status: OrderStatus;
  items: OrderItem[];
  createdAt: string;
}

export interface CartItem {
  productId: string;
  quantity: number;
}

export interface DailySalesPoint {
  date: string;
  label: string;
  revenue: number;
  ordersCount: number;
  itemsSold: number;
}

export interface CategorySalesBreakdown {
  categoryId: string;
  categoryName: string;
  columnOrder: number;
  revenue: number;
  unitsSold: number;
  totalProducts: number;
  inStockCount: number;
  outOfStockCount: number;
  totalInventoryUnits: number;
}

export interface TopProductStat {
  productId: string;
  sku: string;
  name: string;
  categoryId: string;
  categoryName: string;
  unitsSold: number;
  revenue: number;
  currentStock: number;
}

export interface SalesAnalytics {
  range: 'today' | '7d' | '30d' | 'all';
  categoryFilter: string;
  totalRevenue: number;
  grossSubtotal: number;
  totalShipping: number;
  ordersCount: number;
  itemsSoldCount: number;
  averageOrderValue: number;
  inStockProductsCount: number;
  outOfStockProductsCount: number;
  lowStockProductsCount: number;
  totalProductsCount: number;
  dailySeries: DailySalesPoint[];
  categoryBreakdown: CategorySalesBreakdown[];
  topProducts: TopProductStat[];
}

export interface CustomerUser {
  name: string;
  phone: string;
}

export interface CustomerLocation {
  id: string;
  label: string;
  address: string;
  postalCode?: string;
  lat?: number;
  lng?: number;
  updatedAt: string;
}

export interface OtpRequestRecord {
  id: string;
  customerName: string;
  customerPhone: string;
  code: string;
  smsDispatchedVia: 'webhook' | 'kavenegar' | 'admin_panel';
  status: 'pending' | 'verified';
  createdAt: string;
  expiresAt: string;
  attempts: number;
}

export interface StoreDatabase {
  storeVersion?: string;
  adminCredentialHash?: string;
  otpRequests?: OtpRequestRecord[];
  categories: Category[];
  products: Product[];
  orders: Order[];
}

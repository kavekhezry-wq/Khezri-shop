# راهنمای کامل راه‌اندازی و اتصال فروشگاه خضری به سرور اختصاصی

این برنامه بر پایه **Node.js (نسخه ۲۰ به بالا)**، **Express** و **React + Vite** ساخته شده است و به ۳ روش بسیار ساده می‌توانید آن را روی هر سروری راه‌اندازی کنید:

---

## روش اول: سریع‌ترین روش با Docker (پیشنهادی برای تمام سرورهای مجازی VPS)

اگر روی سرور لینوکس خود **Docker** و **Docker Compose** نصب دارید:

۱. فایل فشرده `khezri-store-app.zip` را روی سرور آپلود و از حالت فشرده خارج کنید:
```bash
unzip khezri-store-app.zip -d khezri-store
cd khezri-store
```

۲. با یک دستور، برنامه را اجرا کنید:
```bash
docker compose up -d --build
```
برنامه روی پورت **3000** سرور شما فعال و پایدار می‌ماند و با ری‌استارت سرور نیز به‌طور خودکار بالا می‌آید. اطلاعات کالاها و سفارش‌ها نیز در volume ذخیره و حفظ می‌شوند.

---

## روش دوم: استقرار روی سرور لینوکس مجازی (Ubuntu / Debian) با PM2 و Nginx

### ۱. نصب پیش‌نیازها روی سرور
```bash
sudo apt update
sudo apt install -y nodejs npm unzip nginx
sudo npm install -g n
sudo n 22
sudo npm install -g pm2
```

### ۲. استخراج و بیلد پروژه
```bash
unzip khezri-store-app.zip -d /var/www/khezri-store
cd /var/www/khezri-store
npm install
npm run build
```

### ۳. اجرا در پس‌زمینه با PM2
```bash
NODE_ENV=production pm2 start "npx tsx server.ts" --name "khezri-store"
pm2 save
pm2 startup
```

### ۴. تنظیم دامنه و Nginx (پورت 80 و SSL رایگان)
فایل `/etc/nginx/sites-available/khezri` را با دستور زیر ویرایش کنید:
```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com; # دامنه خود را بنویسید

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
فعال‌سازی Nginx:
```bash
sudo ln -s /etc/nginx/sites-available/khezri /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

برای دریافت گواهی امنیتی SSL رایگان (HTTPS):
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

---

## روش سوم: پلتفرم‌های ابری ایرانی (لیارا، چابکان و ...)

اگر از هاست ابری نودجی‌اس یا سرویس‌های ابری ایرانی مثل **لیارا (Liara)** استفاده می‌کنید:
۱. در پنل لیارا یک برنامه **Node.js** یا **Docker** ایجاد کنید.
۲. با نرم‌افزار دسکتاپ لیارا یا دستور `liara deploy` پوشه پروژه را آپلود نمایید.
۳. دستور شروع برنامه (`Start Command`):
```bash
npm start
```
و دستور بیلد (`Build Command`):
```bash
npm run build
```

---

## تنظیمات متغیرهای محیطی (`.env`) روی سرور
در فایل `.env` روی سرور می‌توانید مقادیر زیر را در صورت نیاز تغییر دهید:
- `PORT=3000` (پورت اجرای سرور)
- `ADMIN_SMS_RECEIVER="09146265841"` (شماره دریافت پیامک و کدهای ورود)
- `KAVENEGAR_API_KEY=` (کلید وب‌سرویس پیامک کاوه‌نگار در صورت تمایل به ارسال خودکار تلکام)
- `ADMIN_PASSCODE=` (رمز عبور مدیریت؛ در صورت خالی بودن در اولین ورود از طریق مرورگر تنظیم می‌شود)

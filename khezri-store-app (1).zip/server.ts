import crypto from 'crypto';
import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'fs';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import type { Order, OrderItem, OrderStatus, OtpRequestRecord, Product } from './src/types/store';
import { computeSalesAnalytics, readDb, writeDb } from './server/db';

const PORT = Number(process.env.PORT) || 3000;
const ADMIN_SESSION_SECRET =
  process.env.ADMIN_SESSION_SECRET?.trim() || crypto.randomBytes(32).toString('hex');
const ADMIN_TOKEN_TTL_MS = 12 * 60 * 60 * 1000;
const revokedTokenIds = new Set<string>();

// Simple in-memory rate limit for admin auth endpoints
const authAttempts = new Map<string, { count: number; resetAt: number }>();

function checkAuthRateLimit(ip: string): boolean {
  const now = Date.now();
  const rec = authAttempts.get(ip);
  if (!rec || rec.resetAt <= now) {
    return true;
  }
  return rec.count < 8;
}

function recordFailedAuthAttempt(ip: string): void {
  const now = Date.now();
  const rec = authAttempts.get(ip);
  if (!rec || rec.resetAt <= now) {
    authAttempts.set(ip, { count: 1, resetAt: now + 5 * 60 * 1000 });
  } else {
    rec.count += 1;
  }
}

function clearAuthAttempts(ip: string): void {
  authAttempts.delete(ip);
}

function getEnvAdminPasscode(): string {
  return (process.env.ADMIN_PASSCODE || '').trim();
}

function hashAdminPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const derived = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${derived}`;
}

function verifyScryptPassword(password: string, stored: string): boolean {
  const parts = stored.split(':');
  if (parts.length !== 2) return false;
  const [salt, storedHex] = parts;
  if (!salt || !storedHex) return false;
  try {
    const derived = crypto.scryptSync(password, salt, 64);
    const storedBuf = Buffer.from(storedHex, 'hex');
    if (derived.length !== storedBuf.length) return false;
    return crypto.timingSafeEqual(derived, storedBuf);
  } catch {
    return false;
  }
}

function verifyEnvPasscode(password: string, envPasscode: string): boolean {
  const candidateDigest = crypto.createHash('sha256').update(password).digest();
  const targetDigest = crypto.createHash('sha256').update(envPasscode).digest();
  return crypto.timingSafeEqual(candidateDigest, targetDigest);
}

function verifyAdminCredential(password: string, storedHash?: string): boolean {
  const envPass = getEnvAdminPasscode();
  if (envPass) {
    return verifyEnvPasscode(password, envPass);
  }
  if (storedHash) {
    return verifyScryptPassword(password, storedHash);
  }
  return false;
}

interface SessionTokenPayload {
  role: 'admin' | 'customer';
  customerName?: string;
  customerPhone?: string;
  jti: string;
  exp: number;
}

function signToken(payload: SessionTokenPayload): string {
  const encodedPayload = Buffer.from(JSON.stringify(payload), 'utf-8').toString('base64url');
  const signature = crypto
    .createHmac('sha256', ADMIN_SESSION_SECRET)
    .update(encodedPayload)
    .digest('base64url');
  return `${encodedPayload}.${signature}`;
}

function createAdminToken(): string {
  return signToken({
    role: 'admin',
    jti: crypto.randomBytes(16).toString('hex'),
    exp: Date.now() + ADMIN_TOKEN_TTL_MS,
  });
}

function createCustomerToken(customerName: string, customerPhone: string): string {
  return signToken({
    role: 'customer',
    customerName,
    customerPhone,
    jti: crypto.randomBytes(16).toString('hex'),
    exp: Date.now() + 7 * 24 * 60 * 60 * 1000,
  });
}

function verifySessionToken(token: string): SessionTokenPayload | null {
  const dotIdx = token.indexOf('.');
  if (dotIdx <= 0) return null;
  const encodedPayload = token.slice(0, dotIdx);
  const signature = token.slice(dotIdx + 1);
  if (!encodedPayload || !signature) return null;

  const expectedSig = crypto
    .createHmac('sha256', ADMIN_SESSION_SECRET)
    .update(encodedPayload)
    .digest('base64url');

  const sigBuf = Buffer.from(signature, 'utf-8');
  const expBuf = Buffer.from(expectedSig, 'utf-8');
  if (sigBuf.length !== expBuf.length || !crypto.timingSafeEqual(sigBuf, expBuf)) {
    return null;
  }

  try {
    const parsed = JSON.parse(
      Buffer.from(encodedPayload, 'base64url').toString('utf-8'),
    ) as SessionTokenPayload;
    if (
      (parsed.role !== 'admin' && parsed.role !== 'customer') ||
      typeof parsed.jti !== 'string' ||
      typeof parsed.exp !== 'number' ||
      parsed.exp <= Date.now() ||
      revokedTokenIds.has(parsed.jti)
    ) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

function verifyAdminToken(token: string): SessionTokenPayload | null {
  const parsed = verifySessionToken(token);
  return parsed && parsed.role === 'admin' ? parsed : null;
}

function extractBearerToken(req: Request): string | null {
  const auth = req.headers.authorization;
  if (!auth || !auth.startsWith('Bearer ')) return null;
  return auth.slice(7).trim() || null;
}

const SAFE_SERVER_DATA_IMG_RE = /^data:image\/(png|jpe?g|webp);base64,[A-Za-z0-9+/=]+$/i;

function sanitizeServerImageUrl(raw: unknown): string | undefined {
  if (typeof raw !== 'string') return undefined;
  const trimmed = raw.trim();
  if (!trimmed) return undefined;
  if (SAFE_SERVER_DATA_IMG_RE.test(trimmed) && trimmed.length <= 500_000) {
    return trimmed;
  }
  if (trimmed.startsWith('/') && !trimmed.startsWith('//') && !trimmed.includes('..')) {
    return trimmed;
  }
  try {
    const parsed = new URL(trimmed);
    if (parsed.protocol === 'https:' || parsed.protocol === 'http:') {
      return parsed.toString();
    }
  } catch {
    return undefined;
  }
  return undefined;
}

function normalizeDigits(input: string): string {
  return input
    .replace(/[۰-۹]/g, (d) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
}

function normalizeIranPhone(raw: unknown): string | null {
  if (typeof raw !== 'string') return null;
  const digits = normalizeDigits(raw).replace(/\D/g, '');
  if (/^09\d{9}$/.test(digits)) return digits;
  if (/^989\d{9}$/.test(digits)) return `0${digits.slice(2)}`;
  if (/^00989\d{9}$/.test(digits)) return `0${digits.slice(4)}`;
  if (/^9\d{9}$/.test(digits)) return `0${digits}`;
  return null;
}

function getAdminSmsReceiver(): string {
  return normalizeIranPhone(process.env.ADMIN_SMS_RECEIVER) || '09146265841';
}

function isSafeOutboundHttpsUrl(rawUrl: string): boolean {
  try {
    const u = new URL(rawUrl);
    if (u.protocol !== 'https:') return false;
    const host = u.hostname.toLowerCase();
    if (
      host === 'localhost' ||
      host === '127.0.0.1' ||
      host === '::1' ||
      host === '169.254.169.254' ||
      host.startsWith('10.') ||
      host.startsWith('192.168.') ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(host)
    ) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

async function dispatchAdminSms(
  customerName: string,
  customerPhone: string,
  code: string,
): Promise<'webhook' | 'kavenegar' | 'admin_panel'> {
  const receiver = getAdminSmsReceiver();
  const message = `فروشگاه خضری | درخواست ورود\nنام: ${customerName}\nشماره: ${customerPhone}\nکد یکبار مصرف: ${code}`;

  const webhookUrl = (process.env.SMS_WEBHOOK_URL || '').trim();
  if (webhookUrl && isSafeOutboundHttpsUrl(webhookUrl)) {
    try {
      const controller = new AbortController();
      const t = setTimeout(() => controller.abort(), 3500);
      const res = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ to: receiver, message, customerName, customerPhone, code }),
        signal: controller.signal,
      });
      clearTimeout(t);
      if (res.ok) return 'webhook';
    } catch {
      // fall through to admin_panel queue
    }
  }

  const kavenegarKey = (process.env.KAVENEGAR_API_KEY || '').trim();
  if (kavenegarKey) {
    try {
      const controller = new AbortController();
      const t = setTimeout(() => controller.abort(), 3500);
      const params = new URLSearchParams({ receptor: receiver, message });
      const res = await fetch(
        `https://api.kavenegar.com/v1/${encodeURIComponent(kavenegarKey)}/sms/send.json`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: params.toString(),
          signal: controller.signal,
        },
      );
      clearTimeout(t);
      if (res.ok) return 'kavenegar';
    } catch {
      // fall through to admin_panel queue
    }
  }

  return 'admin_panel';
}

function requireAdmin(req: Request, res: Response, next: NextFunction): void {
  const token = extractBearerToken(req);
  if (!token || !verifyAdminToken(token)) {
    res.status(401).json({ error: 'دسترسی غیرمجاز. لطفاً ابتدا وارد پنل مدیریت شوید.' });
    return;
  }
  next();
}

function requireAuthenticated(req: Request, res: Response, next: NextFunction): void {
  const token = extractBearerToken(req);
  if (!token || !verifySessionToken(token)) {
    res.status(401).json({ error: 'لطفاً ابتدا با نام، شماره تلفن و کد یکبار مصرف وارد شوید.' });
    return;
  }
  next();
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '2mb' }));

  // Admin auth status
  app.get('/api/admin/status', (req, res) => {
    const db = readDb();
    const envManaged = Boolean(getEnvAdminPasscode());
    const configured = envManaged || Boolean(db.adminCredentialHash);
    const token = extractBearerToken(req);
    const authenticated = Boolean(token && verifyAdminToken(token));
    res.json({ configured, envManaged, authenticated });
  });

  // One-time initial admin password setup (only when neither env passcode nor saved hash exists)
  app.post('/api/admin/setup', (req, res) => {
    const clientIp = req.ip || 'unknown';
    if (!checkAuthRateLimit(clientIp)) {
      res.status(429).json({ error: 'تعداد تلاش‌های ناموفق زیاد است. چند دقیقه دیگر تلاش کنید.' });
      return;
    }

    const db = readDb();
    const envManaged = Boolean(getEnvAdminPasscode());
    if (envManaged || db.adminCredentialHash) {
      res.status(409).json({ error: 'رمز عبور مدیریت قبلاً تنظیم شده است.' });
      return;
    }

    const password = typeof req.body?.password === 'string' ? req.body.password.trim() : '';
    if (password.length < 6 || password.length > 128) {
      res.status(400).json({ error: 'رمز عبور باید بین ۶ تا ۱۲۸ کاراکتر باشد.' });
      return;
    }

    db.adminCredentialHash = hashAdminPassword(password);
    writeDb(db);
    clearAuthAttempts(clientIp);

    const token = createAdminToken();
    res.status(201).json({ token, envManaged: false });
  });

  // Admin login
  app.post('/api/admin/login', (req, res) => {
    const clientIp = req.ip || 'unknown';
    if (!checkAuthRateLimit(clientIp)) {
      res.status(429).json({ error: 'تعداد تلاش‌های ناموفق زیاد است. چند دقیقه دیگر تلاش کنید.' });
      return;
    }

    const db = readDb();
    const envManaged = Boolean(getEnvAdminPasscode());
    if (!envManaged && !db.adminCredentialHash) {
      res.status(409).json({ error: 'ابتدا باید رمز عبور اولیه مدیریت تعیین شود.' });
      return;
    }

    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    if (!password || !verifyAdminCredential(password, db.adminCredentialHash)) {
      recordFailedAuthAttempt(clientIp);
      res.status(401).json({ error: 'رمز عبور اشتباه است.' });
      return;
    }

    clearAuthAttempts(clientIp);
    const token = createAdminToken();
    res.json({ token, envManaged });
  });

  // Change admin password (authenticated, when not managed via env var)
  app.post('/api/admin/change-password', requireAdmin, (req, res) => {
    if (getEnvAdminPasscode()) {
      res.status(400).json({ error: 'رمز مدیریت از طریق تنظیمات محیطی سرور کنترل می‌شود.' });
      return;
    }

    const db = readDb();
    const currentPassword =
      typeof req.body?.currentPassword === 'string' ? req.body.currentPassword : '';
    const newPassword =
      typeof req.body?.newPassword === 'string' ? req.body.newPassword.trim() : '';

    if (!currentPassword || !verifyAdminCredential(currentPassword, db.adminCredentialHash)) {
      res.status(401).json({ error: 'رمز عبور فعلی صحیح نیست.' });
      return;
    }
    if (newPassword.length < 6 || newPassword.length > 128) {
      res.status(400).json({ error: 'رمز عبور جدید باید بین ۶ تا ۱۲۸ کاراکتر باشد.' });
      return;
    }

    db.adminCredentialHash = hashAdminPassword(newPassword);
    writeDb(db);
    res.json({ ok: true });
  });

  // Logout (revoke current session token)
  app.post('/api/admin/logout', requireAdmin, (req, res) => {
    const token = extractBearerToken(req);
    const payload = token ? verifyAdminToken(token) : null;
    if (payload) {
      revokedTokenIds.add(payload.jti);
    }
    res.json({ ok: true });
  });

  // Customer OTP login: Step 1 - Request 6-digit OTP (dispatched to admin receiver 09146265841 & queued in admin panel)
  app.post('/api/auth/request-otp', async (req, res) => {
    const clientIp = req.ip || 'unknown';
    if (!checkAuthRateLimit(clientIp)) {
      res.status(429).json({ error: 'تعداد درخواست‌ها زیاد است. چند دقیقه دیگر تلاش کنید.' });
      return;
    }

    const rawName = typeof req.body?.name === 'string' ? req.body.name.trim() : '';
    const phone = normalizeIranPhone(req.body?.phone);

    if (rawName.length < 2 || rawName.length > 80) {
      res.status(400).json({ error: 'لطفاً نام و نام خانوادگی معتبر وارد کنید.' });
      return;
    }
    if (!phone) {
      res.status(400).json({ error: 'شماره موبایل معتبر نیست (مثال: 09123456789).' });
      return;
    }

    const code = String(crypto.randomInt(100000, 1000000));
    const nowMs = Date.now();
    const smsDispatchedVia = await dispatchAdminSms(rawName, phone, code);

    const db = readDb();
    const existingList = (db.otpRequests ?? []).filter(
      (r) => !(r.customerPhone === phone && r.status === 'pending'),
    );

    const record: OtpRequestRecord = {
      id: `otp-${nowMs}-${crypto.randomBytes(3).toString('hex')}`,
      customerName: rawName,
      customerPhone: phone,
      code,
      smsDispatchedVia,
      status: 'pending',
      createdAt: new Date(nowMs).toISOString(),
      expiresAt: new Date(nowMs + 10 * 60 * 1000).toISOString(),
      attempts: 0,
    };

    db.otpRequests = [record, ...existingList].slice(0, 50);
    writeDb(db);

    res.status(201).json({
      ok: true,
      phone,
      adminPhone: getAdminSmsReceiver(),
      smsDispatchedVia,
      expiresInSeconds: 600,
    });
  });

  // Customer OTP login: Step 2 - Verify 6-digit OTP & issue customer Bearer session
  app.post('/api/auth/verify-otp', (req, res) => {
    const clientIp = req.ip || 'unknown';
    if (!checkAuthRateLimit(clientIp)) {
      res.status(429).json({ error: 'تعداد تلاش‌های ناموفق زیاد است. چند دقیقه دیگر تلاش کنید.' });
      return;
    }

    const phone = normalizeIranPhone(req.body?.phone);
    const rawCode = typeof req.body?.code === 'string' ? normalizeDigits(req.body.code).replace(/\D/g, '') : '';

    if (!phone) {
      res.status(400).json({ error: 'شماره موبایل معتبر نیست.' });
      return;
    }
    if (rawCode.length !== 6) {
      res.status(400).json({ error: 'لطفاً کد ۶ رقمی یکبار مصرف را کامل وارد کنید.' });
      return;
    }

    const db = readDb();
    const list = db.otpRequests ?? [];
    const idx = list.findIndex((r) => r.customerPhone === phone && r.status === 'pending');
    if (idx === -1) {
      recordFailedAuthAttempt(clientIp);
      res.status(401).json({ error: 'درخواست فعالی برای این شماره یافت نشد. دوباره درخواست کد بدهید.' });
      return;
    }

    const record = list[idx];
    if (new Date(record.expiresAt).getTime() <= Date.now()) {
      res.status(410).json({ error: 'کد یکبار مصرف منقضی شده است. لطفاً کد جدید درخواست کنید.' });
      return;
    }
    if (record.attempts >= 5) {
      res.status(429).json({ error: 'تعداد تلاش اشتباه بیش از حد مجاز است. کد جدید درخواست کنید.' });
      return;
    }

    const expectedBuf = Buffer.from(record.code, 'utf-8');
    const providedBuf = Buffer.from(rawCode, 'utf-8');
    const matched =
      expectedBuf.length === providedBuf.length && crypto.timingSafeEqual(expectedBuf, providedBuf);

    if (!matched) {
      record.attempts += 1;
      writeDb(db);
      recordFailedAuthAttempt(clientIp);
      res.status(401).json({ error: 'کد واردشده اشتباه است.' });
      return;
    }

    record.status = 'verified';
    writeDb(db);
    clearAuthAttempts(clientIp);

    const token = createCustomerToken(record.customerName, record.customerPhone);
    res.json({
      token,
      customer: {
        name: record.customerName,
        phone: record.customerPhone,
      },
    });
  });

  // Customer/Admin shared logout
  app.post('/api/auth/logout', requireAuthenticated, (req, res) => {
    const token = extractBearerToken(req);
    const payload = token ? verifySessionToken(token) : null;
    if (payload) {
      revokedTokenIds.add(payload.jti);
    }
    res.json({ ok: true });
  });

  // Admin OTP queue inspection & cleanup
  app.get('/api/admin/otp-requests', requireAdmin, (_req, res) => {
    const db = readDb();
    res.json({
      adminSmsReceiver: getAdminSmsReceiver(),
      smsGatewayConfigured: Boolean(
        (process.env.SMS_WEBHOOK_URL || '').trim() || (process.env.KAVENEGAR_API_KEY || '').trim(),
      ),
      requests: db.otpRequests ?? [],
    });
  });

  app.delete('/api/admin/otp-requests/:id', requireAdmin, (req, res) => {
    const db = readDb();
    db.otpRequests = (db.otpRequests ?? []).filter((r) => r.id !== req.params.id);
    writeDb(db);
    res.json({ deletedId: req.params.id });
  });

  // Download complete project package ZIP
  app.get('/api/download-app', (_req, res) => {
    const zipPath = path.resolve(process.cwd(), 'public', 'khezri-store-app.zip');
    if (fs.existsSync(zipPath)) {
      res.download(zipPath, 'khezri-store-app.zip');
    } else {
      res.status(404).json({ error: 'فایل پروژه آماده نیست.' });
    }
  });

  // Storefront bootstrap: all 10 categories & products (authenticated customer or admin only)
  app.get('/api/storefront', requireAuthenticated, (_req, res) => {
    const db = readDb();
    res.json({
      categories: db.categories.slice().sort((a, b) => a.columnOrder - b.columnOrder),
      products: db.products,
      serverTime: new Date().toISOString(),
    });
  });

  // Create product (admin only)
  app.post('/api/products', requireAdmin, (req, res) => {
    const db = readDb();
    const { name, sku, categoryId, price, stock, brand, description, imageUrl } = req.body ?? {};

    if (!name || typeof name !== 'string' || !categoryId || typeof price !== 'number' || price < 0) {
      res.status(400).json({ error: 'نام محصول، دسته‌بندی و قیمت معتبر الزامی است.' });
      return;
    }

    const category = db.categories.find((c) => c.id === categoryId);
    if (!category) {
      res.status(404).json({ error: 'دسته‌بندی انتخاب‌شده یافت نشد.' });
      return;
    }

    const nowIso = new Date().toISOString();
    const cleanStock = Math.max(0, Math.floor(Number(stock) || 0));
    const cleanImageUrl = sanitizeServerImageUrl(imageUrl);
    const newProduct: Product = {
      id: `gprod-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      sku:
        typeof sku === 'string' && sku.trim()
          ? sku.trim()
          : `KH-${category.columnOrder}${String(db.products.length + 1).padStart(3, '0')}`,
      name: name.trim(),
      categoryId,
      price: Math.round(price),
      stock: cleanStock,
      description:
        typeof description === 'string' && description.trim()
          ? description.trim()
          : `${name.trim()} در دسته‌بندی ${category.name} فروشگاه خضری.`,
      brand: typeof brand === 'string' && brand.trim() ? brand.trim() : 'برند منتخب',
      ...(cleanImageUrl ? { imageUrl: cleanImageUrl } : {}),
      salesCount: 0,
      createdAt: nowIso,
      updatedAt: nowIso,
    };

    db.products.unshift(newProduct);
    writeDb(db);
    res.status(201).json(newProduct);
  });

  // Full product update (admin only)
  app.put('/api/products/:id', requireAdmin, (req, res) => {
    const db = readDb();
    const idx = db.products.findIndex((p) => p.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'محصول مورد نظر یافت نشد.' });
      return;
    }

    const existing = db.products[idx];
    const { name, sku, categoryId, price, stock, brand, description, imageUrl } = req.body ?? {};
    const hasImageField = Object.prototype.hasOwnProperty.call(req.body ?? {}, 'imageUrl');
    const nextImageUrl = hasImageField ? sanitizeServerImageUrl(imageUrl) : existing.imageUrl;

    const updated: Product = {
      ...existing,
      name: typeof name === 'string' && name.trim() ? name.trim() : existing.name,
      sku: typeof sku === 'string' && sku.trim() ? sku.trim() : existing.sku,
      categoryId:
        typeof categoryId === 'string' && db.categories.some((c) => c.id === categoryId)
          ? categoryId
          : existing.categoryId,
      price: typeof price === 'number' && price >= 0 ? Math.round(price) : existing.price,
      stock: typeof stock === 'number' && stock >= 0 ? Math.floor(stock) : existing.stock,
      brand: typeof brand === 'string' && brand.trim() ? brand.trim() : existing.brand,
      description: typeof description === 'string' ? description.trim() : existing.description,
      imageUrl: nextImageUrl,
      updatedAt: new Date().toISOString(),
    };
    if (!nextImageUrl) {
      delete updated.imageUrl;
    }

    db.products[idx] = updated;
    writeDb(db);
    res.json(updated);
  });

  // Fast inline stock/price patch for quick admin operations (admin only)
  app.patch('/api/products/:id/quick', requireAdmin, (req, res) => {
    const db = readDb();
    const idx = db.products.findIndex((p) => p.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'محصول یافت نشد.' });
      return;
    }

    const existing = db.products[idx];
    const { stock, price } = req.body ?? {};
    const updated: Product = {
      ...existing,
      stock: typeof stock === 'number' ? Math.max(0, Math.floor(stock)) : existing.stock,
      price: typeof price === 'number' && price >= 0 ? Math.round(price) : existing.price,
      updatedAt: new Date().toISOString(),
    };

    db.products[idx] = updated;
    writeDb(db);
    res.json(updated);
  });

  // Delete product (admin only)
  app.delete('/api/products/:id', requireAdmin, (req, res) => {
    const db = readDb();
    const exists = db.products.some((p) => p.id === req.params.id);
    if (!exists) {
      res.status(404).json({ error: 'محصول یافت نشد.' });
      return;
    }
    db.products = db.products.filter((p) => p.id !== req.params.id);
    writeDb(db);
    res.json({ deletedId: req.params.id });
  });

  // Update category column metadata (admin only)
  app.put('/api/categories/:id', requireAdmin, (req, res) => {
    const db = readDb();
    const idx = db.categories.findIndex((c) => c.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'دسته‌بندی یافت نشد.' });
      return;
    }

    const existing = db.categories[idx];
    const { name, description } = req.body ?? {};
    db.categories[idx] = {
      ...existing,
      name: typeof name === 'string' && name.trim() ? name.trim() : existing.name,
      description: typeof description === 'string' ? description.trim() : existing.description,
    };
    writeDb(db);
    res.json(db.categories[idx]);
  });

  // Online Payment Checkout (authenticated customer or admin only)
  app.post('/api/checkout', requireAuthenticated, (req, res) => {
    const db = readDb();
    const { customerName, customerPhone, customerAddress, postalCode, cardNumber, items } = req.body ?? {};

    if (!customerName || !customerPhone || !customerAddress || !Array.isArray(items) || items.length === 0) {
      res.status(400).json({ error: 'اطلاعات گیرنده و اقلام سبد خرید باید کامل باشد.' });
      return;
    }

    const cleanCard = String(cardNumber || '').replace(/\D/g, '');
    if (cleanCard.length < 16) {
      res.status(400).json({ error: 'شماره کارت بانکی ۱۶ رقمی معتبر وارد نمایید.' });
      return;
    }

    const nowMs = Date.now();
    const productMap = new Map(db.products.map((p) => [p.id, p]));
    const orderItems: OrderItem[] = [];
    let subtotal = 0;

    // Validate stock before mutating
    for (const reqItem of items) {
      const qty = Math.floor(Number(reqItem.quantity) || 0);
      const prod = productMap.get(reqItem.productId);
      if (!prod) {
        res.status(404).json({ error: `کالای انتخاب‌شده در فروشگاه یافت نشد.` });
        return;
      }
      if (qty <= 0) {
        res.status(400).json({ error: `تعداد کالا برای ${prod.name} نامعتبر است.` });
        return;
      }
      if (prod.stock < qty) {
        res.status(409).json({
          error: `موجودی «${prod.name}» کافی نیست (موجودی فعلی: ${prod.stock} عدد).`,
        });
        return;
      }

      const lineTotal = prod.price * qty;
      subtotal += lineTotal;

      orderItems.push({
        productId: prod.id,
        productName: prod.name,
        categoryId: prod.categoryId,
        sku: prod.sku,
        quantity: qty,
        unitPrice: prod.price,
        lineTotal,
      });
    }

    // Deduct stock atomically
    for (const item of orderItems) {
      const prod = productMap.get(item.productId)!;
      prod.stock -= item.quantity;
      prod.salesCount += item.quantity;
      prod.updatedAt = new Date(nowMs).toISOString();
    }

    const shippingCost = subtotal >= 1500000 ? 0 : 65000;
    const finalTotal = subtotal + shippingCost;
    const nextNum = 2040 + db.orders.length + 1;

    const newOrder: Order = {
      id: `ORD-${nextNum}`,
      trackingCode: `KH-${Math.floor(100000 + Math.random() * 899999)}`,
      customerName: String(customerName).trim(),
      customerPhone: String(customerPhone).trim(),
      customerAddress: String(customerAddress).trim(),
      postalCode: String(postalCode || '').trim() || '1415500000',
      paymentMethod: 'online_gateway',
      cardLast4: cleanCard.slice(-4),
      subtotal,
      shippingCost,
      finalTotal,
      status: 'paid',
      items: orderItems,
      createdAt: new Date(nowMs).toISOString(),
    };

    db.orders.unshift(newOrder);
    writeDb(db);

    res.status(201).json({ order: newOrder });
  });

  // Orders & status management (admin only)
  app.get('/api/orders', requireAdmin, (_req, res) => {
    const db = readDb();
    res.json({ orders: db.orders });
  });

  app.patch('/api/orders/:id/status', requireAdmin, (req, res) => {
    const db = readDb();
    const idx = db.orders.findIndex((o) => o.id === req.params.id);
    if (idx === -1) {
      res.status(404).json({ error: 'سفارش یافت نشد.' });
      return;
    }
    const validStatuses: OrderStatus[] = ['paid', 'preparing', 'shipped', 'delivered'];
    const status = req.body?.status;
    if (!validStatuses.includes(status)) {
      res.status(400).json({ error: 'وضعیت سفارش نامعتبر است.' });
      return;
    }
    db.orders[idx].status = status;
    writeDb(db);
    res.json(db.orders[idx]);
  });

  // Accurate Sales Analytics endpoint (admin only)
  app.get('/api/analytics', requireAdmin, (req, res) => {
    const db = readDb();
    const rangeParam = req.query.range;
    const range =
      rangeParam === 'today' || rangeParam === '7d' || rangeParam === '30d' || rangeParam === 'all'
        ? rangeParam
        : '30d';
    const categoryFilter = typeof req.query.categoryId === 'string' ? req.query.categoryId : 'all';

    const analytics = computeSalesAnalytics(db, range, categoryFilter);
    res.json(analytics);
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });

    // When HMR is disabled in the iframe proxy, Vite dev modules (CSS / React Refresh)
    // still import /@vite/client for updateStyle/injectQuery/createHotContext.
    // Serving a WebSocket-free ESM shim prevents `WebSocket closed without opened.` errors.
    app.get('/@vite/client', (_req, res) => {
      res.type('application/javascript').send(`
const sheetsMap = new Map();
const linkSheetsMap = new Map();
if ("document" in globalThis) {
  document.querySelectorAll("style[data-vite-dev-id]").forEach((el) => {
    sheetsMap.set(el.getAttribute("data-vite-dev-id"), el);
  });
  document.querySelectorAll('link[rel="stylesheet"][data-vite-dev-id]').forEach((el) => {
    linkSheetsMap.set(el.getAttribute("data-vite-dev-id"), el);
  });
}
export function updateStyle(id, content) {
  if (linkSheetsMap.has(id)) return;
  let style = sheetsMap.get(id);
  if (!style) {
    style = document.createElement("style");
    style.setAttribute("type", "text/css");
    style.setAttribute("data-vite-dev-id", id);
    style.textContent = content;
    document.head.appendChild(style);
  } else if (style.textContent !== content) {
    style.textContent = content;
  }
  sheetsMap.set(id, style);
}
export function removeStyle(id) {
  if (linkSheetsMap.has(id)) {
    document
      .querySelectorAll(\`link[rel="stylesheet"][data-vite-dev-id="\${CSS.escape(id)}"]\`)
      .forEach((el) => el.remove());
    linkSheetsMap.delete(id);
  }
  const style = sheetsMap.get(id);
  if (style && style.parentNode) {
    style.parentNode.removeChild(style);
    sheetsMap.delete(id);
  }
}
export function createHotContext() {
  const noop = () => {};
  return {
    data: {},
    accept: noop,
    acceptExports: noop,
    dispose: noop,
    prune: noop,
    decline: noop,
    invalidate: noop,
    on: noop,
    off: noop,
    send: noop,
  };
}
export function injectQuery(url, queryToInject) {
  if (url[0] !== "." && url[0] !== "/") return url;
  const pathname = url.replace(/[?#].*$/, "");
  const { search, hash } = new URL(url, "http://vite.dev");
  return \`\${pathname}?\${queryToInject}\${search ? "&" + search.slice(1) : ""}\${hash || ""}\`;
}
export class ErrorOverlay extends HTMLElement {}
`);
    });

    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://localhost:${PORT}`);
  });
}

startServer();

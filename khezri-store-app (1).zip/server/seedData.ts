import type {
  Category,
  Order,
  OrderItem,
  Product,
  StoreDatabase,
} from '../src/types/store';

export const STORE_VERSION = 'khezri-grocery-v2';

const GROCERY_CATEGORY_SPECS: Array<{
  id: string;
  name: string;
  slug: string;
  description: string;
  iconKey: string;
  brands: string[];
  items: Array<{ name: string; price: number; stock: number }>;
}> = [
  {
    id: 'gcat-1',
    name: 'برنج، حبوبات و غلات',
    slug: 'rice-legumes',
    description: 'برنج ایرانی درجه یک، حبوبات پاک‌شده و غلات صبحانه و آشپزی',
    iconKey: 'wheat',
    brands: ['طبیعت', 'گلستان', 'محسن', 'پامچال'],
    items: [
      { name: 'برنج طارم هاشمی فریدونکنار ۵ کیلویی', price: 785000, stock: 18 },
      { name: 'برنج صدری دم‌سیاه آستانه ۱۰ کیلویی', price: 1620000, stock: 9 },
      { name: 'برنج فجر سوزنی گرگان ۵ کیلویی', price: 540000, stock: 24 },
      { name: 'عدس سبز ریز کانادایی ۹۰۰ گرمی', price: 148000, stock: 32 },
      { name: 'لپه آذرشهر اعلا ۹۰۰ گرمی', price: 165000, stock: 21 },
      { name: 'لوبیا چیتی دست‌چین ۹۰۰ گرمی', price: 182000, stock: 0 },
      { name: 'لوبیا قرمز کپسولی ۹۰۰ گرمی', price: 158000, stock: 27 },
      { name: 'لوبیا سفید مجلسی ۹۰۰ گرمی', price: 174000, stock: 14 },
      { name: 'نخود آبگوشتی سایز درشت ۹۰۰ گرمی', price: 139000, stock: 30 },
      { name: 'ماش سبز ریز ایرانی ۹۰۰ گرمی', price: 128000, stock: 19 },
      { name: 'جو پرک صبحانه فوری ۵۰۰ گرمی', price: 78000, stock: 40 },
      { name: 'بلغور گندم سبوس‌دار ۵۰۰ گرمی', price: 62000, stock: 25 },
      { name: 'لپه باقالی خشک شمالی ۵۰۰ گرمی', price: 135000, stock: 11 },
      { name: 'گندم پوست‌کنده حلیم و آش ۹۰۰ گرمی', price: 84000, stock: 0 },
      { name: 'کینوآ سه‌رنگ ارگانیک ۴۰۰ گرمی', price: 215000, stock: 12 },
      { name: 'ذرت خشک پاپ‌کورن ۵۰۰ گرمی', price: 68000, stock: 45 },
      { name: 'سویا خوراکی درشت ۵۰۰ گرمی', price: 72000, stock: 28 },
      { name: 'زرشک پلوئی اعلا قائنات ۲۵۰ گرمی', price: 195000, stock: 16 },
      { name: 'باقالی زرد دوقلو ۵۰۰ گرمی', price: 118000, stock: 0 },
      { name: 'لپه نخودچی خانگی ۵۰۰ گرمی', price: 142000, stock: 20 },
    ],
  },
  {
    id: 'gcat-2',
    name: 'روغن، رب و چاشنی‌ها',
    slug: 'oils-sauces',
    description: 'روغن‌های خوراکی و زیتون، رب گوجه، سرکه، آبلیمو و انواع سس',
    iconKey: 'droplets',
    brands: ['لادن', 'اویلا', 'تبرک', 'مهرام'],
    items: [
      { name: 'روغن آفتابگردان بدون پالم ۸۱۰ گرمی', price: 112000, stock: 36 },
      { name: 'روغن سرخ‌کردنی شفاف ۱.۸ لیتری', price: 225000, stock: 24 },
      { name: 'روغن زیتون فرابکر رودبار ۵۰۰ میلی‌لیتر', price: 465000, stock: 13 },
      { name: 'روغن کنجد بکر تصفیه‌شده ۱ لیتری', price: 520000, stock: 8 },
      { name: 'روغن ذرت خالص ۸۱۰ گرمی', price: 145000, stock: 19 },
      { name: 'رب گوجه‌فرنگی قوطی ۸۰۰ گرمی', price: 79000, stock: 48 },
      { name: 'رب گوجه‌فرنگی شیشه‌ای ۷۰۰ گرمی', price: 94000, stock: 0 },
      { name: 'رب انار ملس شمال ۴۵۰ گرمی', price: 138000, stock: 17 },
      { name: 'سس مایونز کم‌چرب ۴۳۰ گرمی', price: 86000, stock: 31 },
      { name: 'سس کچاپ تند شیشه‌ای ۴۶۰ گرمی', price: 74000, stock: 29 },
      { name: 'سس سالاد فرانسوی ۴۰۰ گرمی', price: 78000, stock: 22 },
      { name: 'آبلیمو طبیعی جهرم ۱ لیتری', price: 118000, stock: 26 },
      { name: 'آبغوره بدون نمک خانگی ۱ لیتری', price: 98000, stock: 15 },
      { name: 'سرکه سیب طبیعی تخمیری ۷۵۰ میلی‌لیتر', price: 89000, stock: 21 },
      { name: 'سرکه بالزامیک اصیل ۲۵۰ میلی‌لیتر', price: 195000, stock: 10 },
      { name: 'خیارشور ویژه شیشه‌ای ۶۸۰ گرمی', price: 96000, stock: 33 },
      { name: 'زیتون سبز بی‌هسته شیشه‌ای ۵۰۰ گرمی', price: 168000, stock: 0 },
      { name: 'ترشی مخلوط خانگی شیشه‌ای ۷۰۰ گرمی', price: 105000, stock: 18 },
      { name: 'سس خردل ملایم ۳۰۰ گرمی', price: 82000, stock: 14 },
      { name: 'سس سویا تیره ۳۰۰ میلی‌لیتر', price: 115000, stock: 0 },
    ],
  },
  {
    id: 'gcat-3',
    name: 'لبنیات و تخم‌مرغ',
    slug: 'dairy-eggs',
    description: 'شیر، ماست، پنیر، کره، خامه، دوغ و تخم‌مرغ تازه روزانه',
    iconKey: 'milk',
    brands: ['کاله', 'میهن', 'پگاه', 'رامک'],
    items: [
      { name: 'شیر کم‌چرب بطری ۱ لیتری', price: 42000, stock: 45 },
      { name: 'شیر پرچرب تازه ۱ لیتری', price: 46000, stock: 38 },
      { name: 'ماست همزده کم‌چرب ۹۰۰ گرمی', price: 68000, stock: 26 },
      { name: 'ماست یونانی پرپروتئین ۴۵۰ گرمی', price: 76000, stock: 19 },
      { name: 'ماست چکیده سنتی موسیر ۶۰۰ گرمی', price: 89000, stock: 15 },
      { name: 'پنیر فتا دوشیزه ۴۰۰ گرمی', price: 98000, stock: 30 },
      { name: 'پنیر سفید ایرانی کم‌نمک ۴۰۰ گرمی', price: 92000, stock: 0 },
      { name: 'پنیر خامه‌ای ویلی ۲۰۰ گرمی', price: 69000, stock: 34 },
      { name: 'پنیر پیتزا موزارلا رنده‌شده ۵۰۰ گرمی', price: 198000, stock: 14 },
      { name: 'پنیر چدار ورقه‌ای تست ۲۰۰ گرمی', price: 112000, stock: 22 },
      { name: 'کره حیوانی پاستوریزه ۱۰۰ گرمی', price: 64000, stock: 41 },
      { name: 'کره گیاهی صبحانه ۲۵۰ گرمی', price: 58000, stock: 28 },
      { name: 'خامه صبحانه عسلی ۲۰۰ میلی‌لیتر', price: 56000, stock: 33 },
      { name: 'دوغ سنتی نعناع‌دار ۱.۵ لیتری', price: 52000, stock: 29 },
      { name: 'تخم‌مرغ بسته ۱۵ عددی زرده طلایی', price: 125000, stock: 25 },
      { name: 'تخم‌مرغ بسته ۹ عددی غنی‌شده امگا۳', price: 88000, stock: 0 },
      { name: 'کشک پاستوریزه شیشه‌ای ۵۰۰ گرمی', price: 84000, stock: 17 },
      { name: 'شیر کاکائو بطری ۲۵۰ میلی‌لیتر', price: 28000, stock: 52 },
      { name: 'پنیر لاکتیکی ۴۵۰ گرمی', price: 96000, stock: 16 },
      { name: 'کفیر پروبیوتیک بطری ۱ لیتری', price: 59000, stock: 12 },
    ],
  },
  {
    id: 'gcat-4',
    name: 'نان، ماکارونی و آرد',
    slug: 'bread-pasta',
    description: 'انواع پاستا و ماکارونی، نان تست تازه، آرد و رشته‌های آشپزی',
    iconKey: 'croissant',
    brands: ['زر ماکارون', 'تک ماکارون', 'سحرخیز', 'گلها'],
    items: [
      { name: 'ماکارونی رشته‌ای قطر ۱.۵ با ۷۰۰ گرم', price: 46000, stock: 50 },
      { name: 'ماکارونی اسپاگتی سبوس‌دار ۵۰۰ گرمی', price: 52000, stock: 28 },
      { name: 'پاستا پنه ریگاته ۵۰۰ گرمی', price: 54000, stock: 33 },
      { name: 'پاستا فوسیلی رنگی ۵۰۰ گرمی', price: 58000, stock: 21 },
      { name: 'لازانیا پیش‌پخت مجلسی ۵۰۰ گرمی', price: 79000, stock: 19 },
      { name: 'رشته آشی سنتی بسته ۵۰۰ گرمی', price: 44000, stock: 37 },
      { name: 'رشته پلویی بوداده ۴۰۰ گرمی', price: 42000, stock: 0 },
      { name: 'ورمیشل سوپ خردشده ۴۰۰ گرمی', price: 36000, stock: 42 },
      { name: 'نان تست هفت‌غله ۵۰۰ گرمی', price: 56000, stock: 15 },
      { name: 'نان تست سفید نرم ۴۵۰ گرمی', price: 48000, stock: 22 },
      { name: 'نان همبرگر کنجدی بسته ۶ عددی', price: 52000, stock: 18 },
      { name: 'آرد سفید قنادی الک‌شده ۱ کیلویی', price: 64000, stock: 31 },
      { name: 'آرد گندم کامل سبوس‌دار ۱ کیلویی', price: 69000, stock: 17 },
      { name: 'آرد برنج معطر خانگی ۵۰۰ گرمی', price: 78000, stock: 0 },
      { name: 'آرد ذرت خوراکی ۲۵۰ گرمی', price: 45000, stock: 26 },
      { name: 'پودر سوخاری طلایی پانکو ۲۰۰ گرمی', price: 58000, stock: 34 },
      { name: 'پودر کیک وانیلی ۵۰۰ گرمی', price: 82000, stock: 20 },
      { name: 'پودر خمیر پیتزا فوری ۵۰۰ گرمی', price: 66000, stock: 14 },
      { name: 'نان جو رژیمی بسته ۳۰۰ گرمی', price: 62000, stock: 0 },
      { name: 'خمیر یوفکا ورقه‌ای مستطیلی ۴۰۰ گرمی', price: 74000, stock: 11 },
    ],
  },
  {
    id: 'gcat-5',
    name: 'نوشیدنی، چای و قهوه',
    slug: 'beverages-tea',
    description: 'چای ایرانی و خارجی، دانه و پودر قهوه، دمنوش و نوشیدنی‌ها',
    iconKey: 'coffee',
    brands: ['گلستان', 'شهرزاد', 'احمد', 'بن‌مانو'],
    items: [
      { name: 'چای سیاه ممتاز ارل گری ۵۰۰ گرمی', price: 295000, stock: 24 },
      { name: 'چای بهاره سرگل لاهیجان ۴۵۰ گرمی', price: 265000, stock: 18 },
      { name: 'چای سبز کیسه‌ای ۲۵ عددی با لیمو', price: 92000, stock: 35 },
      { name: 'قهوه ترک مدیوم ۲۵۰ گرمی', price: 245000, stock: 22 },
      { name: 'قهوه اسپرسو ۱۰۰٪ عربیکا ۲۵۰ گرمی', price: 320000, stock: 14 },
      { name: 'قهوه فوری کلاسیک شیشه‌ای ۱۰۰ گرمی', price: 275000, stock: 16 },
      { name: 'هات چاکلت بسته ۱۰ ساشه تکی', price: 118000, stock: 0 },
      { name: 'کاپوچینو فوم‌دار بسته ۱۰ عددی', price: 124000, stock: 29 },
      { name: 'دمنوش بهارنارنج و بیدمشک ۲۰ عددی', price: 88000, stock: 21 },
      { name: 'دمنوش بابونه و عسل ۲۰ عددی', price: 84000, stock: 19 },
      { name: 'آب معدنی بسته ۶ عددی ۱.۵ لیتری', price: 68000, stock: 40 },
      { name: 'ماءالشعیر لیمویی شیشه‌ای ۳۲۰ سی‌سی', price: 34000, stock: 48 },
      { name: 'آب انار طبیعی بطری ۱ لیتری', price: 96000, stock: 15 },
      { name: 'آب پرتقال پالپ‌دار ۱ لیتری', price: 88000, stock: 23 },
      { name: 'شربت زعفران و گلاب شیشه‌ای ۷۵۰ میل', price: 185000, stock: 12 },
      { name: 'شربت سکنجبین خیار اصیل ۷۵۰ میل', price: 142000, stock: 0 },
      { name: 'عرق نعناع دوآتیشه ۱ لیتری', price: 94000, stock: 27 },
      { name: 'گلاب ممتاز کاشان ۵۰۰ میلی‌لیتر', price: 112000, stock: 20 },
      { name: 'کافی میت شیشه‌ای ۴۰۰ گرمی', price: 210000, stock: 11 },
      { name: 'چای ماسالا فوری بسته ۱۰ عددی', price: 135000, stock: 0 },
    ],
  },
  {
    id: 'gcat-6',
    name: 'پروتئین و کنسروجات',
    slug: 'protein-canned',
    description: 'کنسرو ماهی تن، خوراک‌های آماده، گوشت و مرغ بسته‌بندی بهداشتی',
    iconKey: 'fish',
    brands: ['شیلتون', 'تحفه', 'یک‌ویک', 'سحر'],
    items: [
      { name: 'کنسرو ماهی تن در روغن زیتون ۱۸۰ گرمی', price: 118000, stock: 34 },
      { name: 'کنسرو ماهی تن دودی ۱۸۰ گرمی', price: 124000, stock: 19 },
      { name: 'خوراک لوبیا چیتی با قارچ ۳۸۰ گرمی', price: 68000, stock: 42 },
      { name: 'کنسرو ذرت شیرین ۳۴۰ گرمی', price: 72000, stock: 28 },
      { name: 'کنسرو نخودفرنگی ممتاز ۳۸۰ گرمی', price: 64000, stock: 25 },
      { name: 'خوراک بادمجان کشک و نعناع ۳۸۰ گرمی', price: 86000, stock: 16 },
      { name: 'قورمه‌سبزی آماده مجلسی ۴۰۰ گرمی', price: 145000, stock: 0 },
      { name: 'فیله مرغ تازه بسته‌بندی ۹۰۰ گرمی', price: 265000, stock: 14 },
      { name: 'سینه مرغ بدون استخوان ۱ کیلویی', price: 245000, stock: 18 },
      { name: 'گوشت چرخ‌کرده مخلوط ۵۰۰ گرمی', price: 385000, stock: 11 },
      { name: 'گوشت خورشتی گوساله ۵۰۰ گرمی', price: 420000, stock: 8 },
      { name: 'همبرگر ۹۰٪ گوشت ۴ عددی', price: 295000, stock: 15 },
      { name: 'ناگت مرغ ترد بسته‌بندی ۵۰۰ گرمی', price: 165000, stock: 23 },
      { name: 'سوسیس کوکتل ۹۰٪ گوشت ۴۰۰ گرمی', price: 188000, stock: 0 },
      { name: 'کالباس خشک ۶۰٪ گوشت ۲۵۰ گرمی', price: 155000, stock: 17 },
      { name: 'فیله ماهی قزل‌آلا پاک‌شده ۶۰۰ گرمی', price: 310000, stock: 9 },
      { name: 'میگو پاک‌شده سایز متوسط ۵۰۰ گرمی', price: 440000, stock: 6 },
      { name: 'شنیتسل مرغ ادویه‌دار ۵۰۰ گرمی', price: 178000, stock: 20 },
      { name: 'عدسی آماده صبحانه ۳۸۰ گرمی', price: 58000, stock: 31 },
      { name: 'فلافل نیمه‌آماده کنجدی ۵۰۰ گرمی', price: 95000, stock: 0 },
    ],
  },
  {
    id: 'gcat-7',
    name: 'قند، شکر، عسل و مربا',
    slug: 'sugar-honey-jam',
    description: 'قند و شکر، عسل‌های طبیعی، مرباجات، حلوا شکری و ارده صبحانه',
    iconKey: 'candy',
    brands: ['اصالت', 'شهدین', 'عقاب', 'سبلان'],
    items: [
      { name: 'شکر سفید دانه ریز ۹۰۰ گرمی', price: 56000, stock: 45 },
      { name: 'قند شکسته کارتنی ۵ کیلویی', price: 325000, stock: 19 },
      { name: 'قند حبه جعبه‌ای ۵۰۰ گرمی', price: 48000, stock: 38 },
      { name: 'نبات زعفرانی چوبی بسته ۱۲ عددی', price: 96000, stock: 27 },
      { name: 'شکر قهوه‌ای نیشکر ۵۰۰ گرمی', price: 78000, stock: 22 },
      { name: 'عسل طبیعی گون سبلان ۵۰۰ گرمی', price: 480000, stock: 14 },
      { name: 'عسل بهارنارنج شمال ۴۰۰ گرمی', price: 390000, stock: 10 },
      { name: 'مربای آلبالو هسته‌گیری‌شده ۳۵۰ گرمی', price: 89000, stock: 29 },
      { name: 'مربای هویج خلالی زعفرانی ۳۵۰ گرمی', price: 78000, stock: 24 },
      { name: 'مربای توت‌فرنگی درسته ۳۵۰ گرمی', price: 94000, stock: 0 },
      { name: 'مربای بالنگ معطر ۳۵۰ گرمی', price: 86000, stock: 15 },
      { name: 'حلوا شکری پسته درشت ۴۰۰ گرمی', price: 145000, stock: 21 },
      { name: 'ارده کنجد سنتی اردکان ۴۵۰ گرمی', price: 168000, stock: 18 },
      { name: 'شیره انگور خالص ملایر ۵۰۰ گرمی', price: 155000, stock: 16 },
      { name: 'شیره خرما طبیعی خوزستان ۵۰۰ گرمی', price: 118000, stock: 25 },
      { name: 'سه شیره مقوی صبحانه ۴۵۰ گرمی', price: 162000, stock: 13 },
      { name: 'کره بادام‌زمینی کرانچی ۳۴۰ گرمی', price: 138000, stock: 0 },
      { name: 'کرم شکلات فندقی صبحانه ۳۵۰ گرمی', price: 175000, stock: 20 },
      { name: 'عسل تک‌نفره بسته‌ای ۲۰ عددی', price: 135000, stock: 30 },
      { name: 'خرما شیره ارده آماده ۲۵۰ گرمی', price: 92000, stock: 0 },
    ],
  },
  {
    id: 'gcat-8',
    name: 'خشکبار و آجیل',
    slug: 'nuts-dried-fruit',
    description: 'پسته، بادام، گردو، خرما، کشمش، انجیر و مخلوط‌های انرژی‌زا',
    iconKey: 'nut',
    brands: ['تواضع', 'حسینی', 'مزمز', 'باغ بهشت'],
    items: [
      { name: 'پسته اکبری برشته زعفرانی ۲۵۰ گرمی', price: 385000, stock: 15 },
      { name: 'مغز گردو تویسرکان سفید ۲۵۰ گرمی', price: 320000, stock: 12 },
      { name: 'بادام درختی خام اعلا ۲۵۰ گرمی', price: 245000, stock: 19 },
      { name: 'بادام هندی برشته نمکی ۲۰۰ گرمی', price: 295000, stock: 11 },
      { name: 'فندق خام پوست‌کنده ۲۰۰ گرمی', price: 275000, stock: 0 },
      { name: 'آجیل چهارمغز خام ۲۵۰ گرمی', price: 360000, stock: 14 },
      { name: 'خرما مضافتی بم جعبه‌ای ۶۵۰ گرمی', price: 148000, stock: 33 },
      { name: 'خرما پیارم مجلسی ۴۵۰ گرمی', price: 235000, stock: 16 },
      { name: 'کشمش سبز قلمی کاشمر ۴۰۰ گرمی', price: 135000, stock: 28 },
      { name: 'مویز بی‌هسته سیاه اعلا ۳۰۰ گرمی', price: 178000, stock: 18 },
      { name: 'انجیر خشک استهبان ۳۰۰ گرمی', price: 225000, stock: 13 },
      { name: 'توت خشک سفید شیرین ۲۰۰ گرمی', price: 165000, stock: 22 },
      { name: 'تخمه آفتابگردان کانادایی ۳۰۰ گرمی', price: 92000, stock: 36 },
      { name: 'تخمه کدو گوشتی برشته ۲۵۰ گرمی', price: 128000, stock: 24 },
      { name: 'برگه زردآلو آفتابی ۳۰۰ گرمی', price: 145000, stock: 0 },
      { name: 'آلو بخارا خورشتی اعلا ۴۰۰ گرمی', price: 168000, stock: 20 },
      { name: 'سنجد کامل و پودر سنجد ۳۰۰ گرمی', price: 115000, stock: 17 },
      { name: 'بادام زمینی روکش‌دار پنیری ۲۰۰ گرمی', price: 84000, stock: 31 },
      { name: 'نخودچی کشمش سنتی ۳۵۰ گرمی', price: 98000, stock: 26 },
      { name: 'میوه خشک مخلوط چیپسی ۱۵۰ گرمی', price: 132000, stock: 0 },
    ],
  },
  {
    id: 'gcat-9',
    name: 'تنقلات و شیرینی',
    slug: 'snacks-sweets',
    description: 'بیسکویت، شکلات، کیک و کلوچه، چیپس، پاستیل و میان‌وعده‌های روزانه',
    iconKey: 'cookie',
    brands: ['فرمند', 'شیرین عسل', 'چی‌توز', 'مزمز'],
    items: [
      { name: 'بیسکویت دایجستیو سبوس‌دار ۲۰۰ گرمی', price: 54000, stock: 42 },
      { name: 'شکلات تلخ ۷۸٪ تخته‌ای ۱۰۰ گرمی', price: 112000, stock: 28 },
      { name: 'شکلات شیری فندقی ۱۰۰ گرمی', price: 98000, stock: 35 },
      { name: 'کلوچه سنتی لاهیجان بسته ۶ عددی', price: 115000, stock: 24 },
      { name: 'کیک صبحانه وانیلی گردویی ۳۵۰ گرمی', price: 86000, stock: 19 },
      { name: 'ویفر کاکائویی ترد بسته ۵ عددی', price: 62000, stock: 31 },
      { name: 'چیپس سیب‌زمینی نمکی ۹۰ گرمی', price: 42000, stock: 48 },
      { name: 'چیپس سرکه‌نمکی تند ۹۰ گرمی', price: 44000, stock: 0 },
      { name: 'اسنک ذرت پنیری ۸۰ گرمی', price: 38000, stock: 39 },
      { name: 'پاپ‌کورن کره‌ای مایکروویوی ۱۰۰ گرمی', price: 48000, stock: 26 },
      { name: 'کراکر نمکی کنجدی ۱۵۰ گرمی', price: 46000, stock: 30 },
      { name: 'پاستیل میوه‌ای بسته ۱۰۰ گرمی', price: 58000, stock: 33 },
      { name: 'لواشک آلوچه ترش متری ۱۰۰ گرمی', price: 45000, stock: 44 },
      { name: 'گز آردی پسته ۲۸٪ جعبه‌ای ۴۵۰ گرمی', price: 245000, stock: 12 },
      { name: 'سوهان عسلی کنجدی قوطی ۳۰۰ گرمی', price: 185000, stock: 14 },
      { name: 'آبنبات نعناعی اکالیپتوس ۱۵۰ گرمی', price: 52000, stock: 25 },
      { name: 'انرژی‌بار جو دوسر و شکلات ۶۰ گرمی', price: 49000, stock: 0 },
      { name: 'پودر ژله آلبالو و توت‌فرنگی بسته ۲ تایی', price: 46000, stock: 37 },
      { name: 'بیسکویت کرمدار شکلاتی ۱۲۰ گرمی', price: 44000, stock: 41 },
      { name: 'رولت خرمایی گردویی ۳۰۰ گرمی', price: 128000, stock: 0 },
    ],
  },
  {
    id: 'gcat-10',
    name: 'ادویه و ملزومات خانگی',
    slug: 'spices-household',
    description: 'زعفران، ادویه‌های تازه، نمک و ملزومات پرمصرف آشپزخانه و منزل',
    iconKey: 'sparkles',
    brands: ['سحرخیز', 'گلها', 'پریل', 'سافتلن'],
    items: [
      { name: 'زعفران سرگل قائنات یک مثقالی', price: 495000, stock: 16 },
      { name: 'زردچوبه خالص هندی ۱۰۰ گرمی', price: 48000, stock: 38 },
      { name: 'فلفل سیاه نیم‌کوب اعلا ۷۰ گرمی', price: 76000, stock: 29 },
      { name: 'فلفل قرمز تند آسیاب‌شده ۷۰ گرمی', price: 54000, stock: 34 },
      { name: 'پودر دارچین سیلان معطر ۸۰ گرمی', price: 68000, stock: 25 },
      { name: 'پودر سیر و پیاز خشک ۸۰ گرمی', price: 62000, stock: 27 },
      { name: 'ادویه کاری ممتاز آبادان ۹۰ گرمی', price: 59000, stock: 31 },
      { name: 'زیره سبز کرمانی پاک‌شده ۱۰۰ گرمی', price: 94000, stock: 18 },
      { name: 'نمک دریا تصفیه‌شده یددار ۱ کیلویی', price: 28000, stock: 55 },
      { name: 'سماق قرمز تبریزی ۱۰۰ گرمی', price: 72000, stock: 0 },
      { name: 'هل سبز اکبر بنفش ۲۰ گرمی', price: 145000, stock: 20 },
      { name: 'مایع ظرفشویی لیمویی ۱ لیتری', price: 98000, stock: 32 },
      { name: 'مایع دستشویی کرمی ۵۰۰ میلی‌لیتر', price: 74000, stock: 36 },
      { name: 'پودر لباسشویی ماشینی ۵۰۰ گرمی', price: 69000, stock: 28 },
      { name: 'مایع لباسشویی رنگین‌شوی ۱ لیتری', price: 148000, stock: 19 },
      { name: 'دستمال کاغذی جعبه‌ای ۲۰۰ برگ بسته ۳ تایی', price: 118000, stock: 24 },
      { name: 'حوله کاغذی آشپزخانه رول دوقلو', price: 86000, stock: 0 },
      { name: 'کیسه زباله رولی بنددار مقاوم ۲۵ عددی', price: 54000, stock: 42 },
      { name: 'کیسه فریزر جعبه‌ای ۲۰۰ عددی ضخیم', price: 68000, stock: 37 },
      { name: 'سلفون غذایی ۳۰ متری برش‌دار', price: 79000, stock: 0 },
    ],
  },
];

export function createInitialDatabase(): StoreDatabase {
  const now = Date.now();
  const baseDateIso = new Date(now - 30 * 86400000).toISOString();

  const categories: Category[] = GROCERY_CATEGORY_SPECS.map((spec, index) => ({
    id: spec.id,
    name: spec.name,
    slug: spec.slug,
    columnOrder: index + 1,
    description: spec.description,
    iconKey: spec.iconKey,
  }));

  const products: Product[] = [];
  GROCERY_CATEGORY_SPECS.forEach((spec, catIdx) => {
    spec.items.forEach((item, itemIdx) => {
      const id = `gprod-${catIdx + 1}-${itemIdx + 1}`;
      const sku = `KH-${String(catIdx + 1).padStart(2, '0')}${String(itemIdx + 1).padStart(2, '0')}`;
      const brand = spec.brands[(catIdx + itemIdx) % spec.brands.length];
      const seededSales = ((catIdx * 7 + itemIdx * 5) % 27) + 4;
      products.push({
        id,
        sku,
        name: item.name,
        categoryId: spec.id,
        price: item.price,
        stock: item.stock,
        description: `${item.name} با کیفیت تضمین‌شده و تاریخ مصرف تازه از برند ${brand} در دسته‌بندی ${spec.name} فروشگاه خضری.`,
        brand,
        salesCount: seededSales,
        createdAt: baseDateIso,
        updatedAt: new Date(now - ((itemIdx % 10) + 1) * 3600000).toISOString(),
      });
    });
  });

  const seedCustomers = [
    { name: 'امیرحسین مرادی', phone: '09123456789', addr: 'تهران، خیابان ولیعصر، پلاک ۱۴۲', zip: '1415512345', card: '6219' },
    { name: 'سارا محمدی', phone: '09129876543', addr: 'اصفهان، بلوار چهارباغ بالا، مجتمع بهار', zip: '8173612345', card: '6037' },
    { name: 'پویا کریمی', phone: '09351122334', addr: 'شیراز، خیابان معالی‌آباد، کوچه ۴', zip: '7187712345', card: '5022' },
    { name: 'نیلوفر رضایی', phone: '09194455667', addr: 'مشهد، بلوار سجاد، نبش بهارستان', zip: '9186712345', card: '6104' },
    { name: 'کیانوش فرهادی', phone: '09125566778', addr: 'تهران، سعادت‌آباد، میدان کاج، واحد ۸', zip: '1998712345', card: '6221' },
    { name: 'الهام کاظمی', phone: '09137788990', addr: 'تبریز، ولیعصر، خیابان همافر', zip: '5157812345', card: '6274' },
  ];

  const orders: Order[] = [];
  const seededBaskets: Array<Array<{ prodIdx: number; qty: number }>> = [
    [{ prodIdx: 0, qty: 2 }, { prodIdx: 20, qty: 3 }, { prodIdx: 40, qty: 4 }],
    [{ prodIdx: 1, qty: 1 }, { prodIdx: 60, qty: 5 }, { prodIdx: 180, qty: 2 }],
    [{ prodIdx: 80, qty: 2 }, { prodIdx: 100, qty: 4 }],
    [{ prodIdx: 140, qty: 2 }, { prodIdx: 125, qty: 2 }],
    [{ prodIdx: 22, qty: 2 }, { prodIdx: 160, qty: 4 }],
    [{ prodIdx: 0, qty: 3 }, { prodIdx: 45, qty: 3 }],
    [{ prodIdx: 84, qty: 2 }, { prodIdx: 121, qty: 1 }],
    [{ prodIdx: 107, qty: 2 }, { prodIdx: 64, qty: 2 }],
    [{ prodIdx: 141, qty: 2 }, { prodIdx: 3, qty: 3 }],
    [{ prodIdx: 1, qty: 2 }, { prodIdx: 181, qty: 3 }],
    [{ prodIdx: 109, qty: 2 }, { prodIdx: 25, qty: 4 }],
    [{ prodIdx: 42, qty: 4 }, { prodIdx: 83, qty: 2 }],
    [{ prodIdx: 146, qty: 3 }, { prodIdx: 0, qty: 1 }],
    [{ prodIdx: 180, qty: 2 }, { prodIdx: 81, qty: 2 }, { prodIdx: 21, qty: 2 }],
  ];

  seededBaskets.forEach((basket, i) => {
    const daysAgo = 13 - i;
    const orderDate = new Date(now - daysAgo * 86400000 - (i % 5) * 3600000).toISOString();
    const cust = seedCustomers[i % seedCustomers.length];

    let subtotal = 0;
    const items: OrderItem[] = basket.map((b) => {
      const p = products[b.prodIdx] ?? products[0];
      const unitPrice = p.price;
      const lineTotal = unitPrice * b.qty;
      subtotal += lineTotal;
      return {
        productId: p.id,
        productName: p.name,
        categoryId: p.categoryId,
        sku: p.sku,
        quantity: b.qty,
        unitPrice,
        lineTotal,
      };
    });

    const shippingCost = subtotal >= 1500000 ? 0 : 65000;
    const finalTotal = subtotal + shippingCost;
    const statuses: Order['status'][] = ['delivered', 'delivered', 'shipped', 'preparing', 'paid'];

    orders.push({
      id: `ORD-${2040 + i}`,
      trackingCode: `KH-${842100 + i * 17}`,
      customerName: cust.name,
      customerPhone: cust.phone,
      customerAddress: cust.addr,
      postalCode: cust.zip,
      paymentMethod: 'online_gateway',
      cardLast4: cust.card,
      subtotal,
      shippingCost,
      finalTotal,
      status: daysAgo === 0 ? 'paid' : statuses[Math.min(4, Math.floor(daysAgo / 3))],
      items,
      createdAt: orderDate,
    });
  });

  orders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return {
    storeVersion: STORE_VERSION,
    categories,
    products,
    orders,
  };
}

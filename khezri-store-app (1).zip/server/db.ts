import fs from 'fs';
import path from 'path';
import type {
  CategorySalesBreakdown,
  DailySalesPoint,
  SalesAnalytics,
  StoreDatabase,
  TopProductStat,
} from '../src/types/store';
import { createInitialDatabase, STORE_VERSION } from './seedData';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'store-db.json');

export function readDb(): StoreDatabase {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  if (!fs.existsSync(DB_PATH)) {
    const initial = createInitialDatabase();
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }

  try {
    const raw = fs.readFileSync(DB_PATH, 'utf-8');
    const parsed = JSON.parse(raw) as StoreDatabase;
    if (
      !parsed.categories ||
      !parsed.products ||
      !parsed.orders ||
      parsed.storeVersion !== STORE_VERSION
    ) {
      throw new Error('Outdated or invalid store-db.json structure');
    }
    return parsed;
  } catch {
    const initial = createInitialDatabase();
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2), 'utf-8');
    return initial;
  }
}

export function writeDb(db: StoreDatabase): void {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  const tmpPath = `${DB_PATH}.tmp`;
  fs.writeFileSync(tmpPath, JSON.stringify(db, null, 2), 'utf-8');
  fs.renameSync(tmpPath, DB_PATH);
}

export function computeSalesAnalytics(
  db: StoreDatabase,
  range: 'today' | '7d' | '30d' | 'all' = '30d',
  categoryFilter: string = 'all',
): SalesAnalytics {
  const now = new Date();
  const nowMs = now.getTime();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();

  let cutoffMs = 0;
  if (range === 'today') {
    cutoffMs = startOfToday;
  } else if (range === '7d') {
    cutoffMs = nowMs - 7 * 86400000;
  } else if (range === '30d') {
    cutoffMs = nowMs - 30 * 86400000;
  }

  const filteredOrders = db.orders.filter((o) => {
    const t = new Date(o.createdAt).getTime();
    return t >= cutoffMs;
  });

  let totalRevenue = 0;
  let grossSubtotal = 0;
  let totalShipping = 0;
  let ordersCount = 0;
  let itemsSoldCount = 0;

  const categoryRevenueMap = new Map<string, { revenue: number; units: number }>();
  const productStatsMap = new Map<string, { units: number; revenue: number; name: string; sku: string; categoryId: string }>();
  const dailyMap = new Map<string, { revenue: number; orders: number; items: number }>();

  const chartDays = range === 'today' ? 1 : range === '7d' ? 7 : 14;
  for (let i = chartDays - 1; i >= 0; i--) {
    const d = new Date(nowMs - i * 86400000);
    const key = d.toISOString().slice(0, 10);
    dailyMap.set(key, { revenue: 0, orders: 0, items: 0 });
  }

  for (const order of filteredOrders) {
    const matchingItems =
      categoryFilter === 'all'
        ? order.items
        : order.items.filter((item) => item.categoryId === categoryFilter);

    if (matchingItems.length === 0) continue;

    ordersCount += 1;

    const orderItemsTotal = matchingItems.reduce((acc, it) => acc + it.lineTotal, 0);
    const orderGrossTotal = matchingItems.reduce((acc, it) => acc + it.unitPrice * it.quantity, 0);
    const orderShipping = categoryFilter === 'all' ? order.shippingCost : 0;
    const orderNet = orderItemsTotal + orderShipping;

    totalRevenue += orderNet;
    grossSubtotal += orderGrossTotal;
    totalShipping += orderShipping;

    const dayKey = order.createdAt.slice(0, 10);
    const dayBucket = dailyMap.get(dayKey);
    const orderItemUnits = matchingItems.reduce((acc, it) => acc + it.quantity, 0);
    itemsSoldCount += orderItemUnits;

    if (dayBucket) {
      dayBucket.revenue += orderNet;
      dayBucket.orders += 1;
      dayBucket.items += orderItemUnits;
    } else if (range === 'all' || range === '30d') {
      dailyMap.set(dayKey, {
        revenue: orderNet,
        orders: 1,
        items: orderItemUnits,
      });
    }

    for (const item of matchingItems) {
      const catCurr = categoryRevenueMap.get(item.categoryId) ?? { revenue: 0, units: 0 };
      catCurr.revenue += item.lineTotal;
      catCurr.units += item.quantity;
      categoryRevenueMap.set(item.categoryId, catCurr);

      const prodCurr = productStatsMap.get(item.productId) ?? {
        units: 0,
        revenue: 0,
        name: item.productName,
        sku: item.sku,
        categoryId: item.categoryId,
      };
      prodCurr.units += item.quantity;
      prodCurr.revenue += item.lineTotal;
      productStatsMap.set(item.productId, prodCurr);
    }
  }

  const dailySeries: DailySalesPoint[] = Array.from(dailyMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-14)
    .map(([date, val]) => {
      let label = date;
      try {
        label = new Intl.DateTimeFormat('fa-IR', { month: 'numeric', day: 'numeric' }).format(
          new Date(`${date}T12:00:00Z`),
        );
      } catch {
        label = date.slice(5);
      }
      return {
        date,
        label,
        revenue: val.revenue,
        ordersCount: val.orders,
        itemsSold: val.items,
      };
    });

  const categoryBreakdown: CategorySalesBreakdown[] = db.categories
    .slice()
    .sort((a, b) => a.columnOrder - b.columnOrder)
    .map((cat) => {
      const catProducts = db.products.filter((p) => p.categoryId === cat.id);
      const sales = categoryRevenueMap.get(cat.id) ?? { revenue: 0, units: 0 };
      return {
        categoryId: cat.id,
        categoryName: cat.name,
        columnOrder: cat.columnOrder,
        revenue: sales.revenue,
        unitsSold: sales.units,
        totalProducts: catProducts.length,
        inStockCount: catProducts.filter((p) => p.stock > 0).length,
        outOfStockCount: catProducts.filter((p) => p.stock <= 0).length,
        totalInventoryUnits: catProducts.reduce((acc, p) => acc + Math.max(0, p.stock), 0),
      };
    });

  const catNameMap = new Map(db.categories.map((c) => [c.id, c.name]));
  const productMap = new Map(db.products.map((p) => [p.id, p]));

  const topProducts: TopProductStat[] = Array.from(productStatsMap.entries())
    .map(([productId, stat]) => {
      const prod = productMap.get(productId);
      return {
        productId,
        sku: stat.sku,
        name: prod?.name ?? stat.name,
        categoryId: stat.categoryId,
        categoryName: catNameMap.get(stat.categoryId) ?? 'سایر',
        unitsSold: stat.units,
        revenue: stat.revenue,
        currentStock: prod?.stock ?? 0,
      };
    })
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 10);

  const scopedProducts =
    categoryFilter === 'all'
      ? db.products
      : db.products.filter((p) => p.categoryId === categoryFilter);

  return {
    range,
    categoryFilter,
    totalRevenue,
    grossSubtotal,
    totalShipping,
    ordersCount,
    itemsSoldCount,
    averageOrderValue: ordersCount > 0 ? Math.round(totalRevenue / ordersCount) : 0,
    inStockProductsCount: scopedProducts.filter((p) => p.stock > 0).length,
    outOfStockProductsCount: scopedProducts.filter((p) => p.stock <= 0).length,
    lowStockProductsCount: scopedProducts.filter((p) => p.stock > 0 && p.stock <= 5).length,
    totalProductsCount: scopedProducts.length,
    dailySeries,
    categoryBreakdown,
    topProducts,
  };
}
